#define SVD "localhost"
#define USR "root"
#define PSW "wederson"
#define BD  "Divulgue_melhor"

MYSQL Conectar(){

	MYSQL Conexao;
	mysql_init(&Conexao);
	mysql_real_connect(&Conexao, SVD, USR, PSW, BD, 0, NULL, 0);
	return Conexao;

}

char *Format(int number){      
   char    *retorno,
      ret[100];
   int    i;

   if (number < 10){
      sprintf(ret,"0%d",number);
      retorno = ret;
      return retorno;
   }
   else{
      sprintf(ret,"%d",number);
      retorno = ret;
      return retorno;
   }
}      

char *Data(void){

   int dia,mes,ano;
   char   var1[100],
      var2[100],
      var3[100],
      var4[100],
      *dataPtr;
   struct tm *local;
   time_t t;

   t = time(NULL);
   local = localtime(&t);

   dia = local -> tm_mday;
   mes = local -> tm_mon +1;
   ano = local -> tm_year + 1900;
   if(dia>15){
   	dia = local -> tm_mday-15;
   }else{
   dia = local -> tm_mday+15;
   mes = local -> tm_mon;

   }
   sprintf(var1,"%s",Format(dia));
   sprintf(var2,"%s",Format(mes));
   sprintf(var3,"%s",Format(ano));

   sprintf(var4,"%s-%s-%s",var3,var2,var1);

   dataPtr = var4;
   return dataPtr;

}


int Checar_Data(char Nome[]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	char data1[10];
	char Query[190];
	sprintf(data1, "%s", Data());
	Conexao=Conectar();
	sprintf(Query,"SELECT Nome FROM Programa_De_TV WHERE H_Alteracao<='%s' AND Nome='%s';",data1, Nome);
	mysql_query(&Conexao, Query);
	Resp=mysql_store_result(&Conexao);

	if((Linhas=mysql_fetch_row(Resp))!=NULL){
		mysql_close(&Conexao);
		return 0;
	}else{
		mysql_close(&Conexao);
		return 1;
	}

}


int N_Linhas_E(char Tema[]){
	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	char Select[200];
	sprintf(Select,"SELECT Tema FROM Programa_De_TV WHERE Tema='%s';",Tema);
	mysql_query(&Conexao,Select);
	Resp=mysql_store_result(&Conexao);
	int L=0;
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		L++;
	}
	mysql_close(&Conexao);
	if(L==1){
		return L+1;
	}else return L;	
}


int N_Linhas(){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	mysql_query(&Conexao,"SELECT DISTINCT Tema FROM Programa_De_TV;");
	Resp=mysql_store_result(&Conexao);
	int L=0;
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		L++;
	}
	mysql_close(&Conexao);
	return L;
}

void Maior_Ibope(int Ideal[][5], int ID){
	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();

	mysql_query(&Conexao, "SELECT ID FROM Filtrado WHERE Ibope=(SELECT MAX(Ibope) FROM Filtrado);");
	Resp=mysql_store_result(&Conexao);
	int Aux=0;

	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		for(int x=0;x<ID;x++){
			if(atoi(Linhas[Aux])==Ideal[x][0]){
				Ideal[x][1]=3;
				break;
			}
		}
		Aux++;
	}
	mysql_close(&Conexao);

}

void D_Horas(int Ideal[][5], int ID){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();

	char Select[200];

	for(int x=0;x<ID;x++){
		sprintf(Select, "SELECT H_Inicial+H_Final FROM Filtrado WHERE ID=%i;",Ideal[x][0]);
		mysql_query(&Conexao, Select);
		Resp=mysql_store_result(&Conexao);

		while((Linhas=mysql_fetch_row(Resp))!=NULL){
		Ideal[x][3]=atoi(Linhas[0]);
			
		}
	}

	int Maior=0;

	for(int x=0;x<ID;x++){
		if(Ideal[x][3]>Maior)Maior=Ideal[x][3];
	}

	for(int x=0;x<ID;x++){
		if(Ideal[x][3]==Maior){
			Ideal[x][3]=2;
		}else{
			Ideal[x][3]=0;
		}
	}

	mysql_close(&Conexao);

}

void Numero_Regioes(int Ideal[][5], int ID){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	int Count;
	char Select[200];
	for(int x=0;x<ID;x++){
		Count=0;
		sprintf(Select, "SELECT DISTINCT ID_Regiao from Programa_Regiao, Filtrado WHERE Programa_Regiao.ID_Programa=%i;",Ideal[x][0]);
		mysql_query(&Conexao, Select);
		Resp=mysql_store_result(&Conexao);
		while((Linhas=mysql_fetch_row(Resp))!=NULL){
			Count++;
		}
		Ideal[x][2]=Count;
	}
	int Maior=0;
	for(int x=0;x<ID;x++){
		if(Ideal[x][2]>Maior)Maior=Ideal[x][2];
	}

	for(int x=0;x<ID;x++){
		if(Ideal[x][2]==Maior){
			Ideal[x][2]=1;
		}else{
			Ideal[x][2]=0;
		}
	}
	mysql_close(&Conexao);

}

void E_Ibope(int Ideal[][5], int ID){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	int Count;
	char Select1[200];
	char Select[200];
	char Emissora[25];

	for(int x=0;x<ID;x++){
		Count=0;
		sprintf(Select1,"SELECT Emissora FROM Filtrado WHERE ID=%i", Ideal[x][0]);
		mysql_query(&Conexao, Select1);
		Resp=mysql_store_result(&Conexao);
		Linhas=mysql_fetch_row(Resp);
		strcpy(Emissora,Linhas[0]);
		sprintf(Select,"SELECT SUM(Ibope) FROM Filtrado WHERE Emissora='%s';",Emissora);
		mysql_query(&Conexao, Select);
		Resp=mysql_store_result(&Conexao);
		Linhas=mysql_fetch_row(Resp);
		Ideal[x][4]=atoi(Linhas[0]);
	}

	int Maior=0;
	for(int x=0;x<ID;x++){
		if(Ideal[x][4]>Maior)Maior=Ideal[x][4];
	}

	for(int x=0;x<ID;x++){
		if(Ideal[x][4]==Maior){
			Ideal[x][4]=2;
		}else{
			Ideal[x][4]=0;
		}
	}
	mysql_close(&Conexao);

}



void Filtro(char Tema[], int Ideal[][5]){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	char Select[200];

	sprintf(Select, "CREATE TABLE Filtrado(SELECT * FROM Programa_De_TV WHERE Tema='%s');",Tema);
	mysql_query(&Conexao, Select);
	mysql_query(&Conexao, "SELECT ID FROM Filtrado;");
	Resp=mysql_store_result(&Conexao);
	int ID=0;
	char q[3];
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		strcpy(q,Linhas[0]);
		Ideal[ID][0]=atoi(q);
		ID++;
	}

	Maior_Ibope(Ideal, ID);
	Numero_Regioes(Ideal, ID);
	D_Horas(Ideal, ID);
	E_Ibope(Ideal, ID);

	mysql_query(&Conexao, "DROP TABLE Filtrado;");
	mysql_close(&Conexao);

}

void Retorna_Dados(int ID, char Nome[]){
	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	char Select[200];
	sprintf(Select,"SELECT Nome FROM Programa_De_TV WHERE ID=%i;",ID);
	mysql_query(&Conexao, Select);
	Resp=mysql_store_result(&Conexao);
	Linhas=mysql_fetch_row(Resp);
	sprintf(Nome,"%s",Linhas[0]);
	mysql_close(&Conexao);
}
int Verifica_Tema(char Tema[]){
	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT Tema FROM Programa_De_TV where Tema='%s';", Tema);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}
}
void Retorna_Temas(char M[][20]){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	mysql_query(&Conexao,"SELECT DISTINCT Tema FROM Programa_De_TV;");
	Resp=mysql_store_result(&Conexao);
	int Aux=0;
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		strcpy(M[Aux],Linhas[0]);
		Aux++;
	}
	mysql_close(&Conexao);

}

void Listar_Regiao(char ID[], char Regiao[]){

	MYSQL Conexao;
	Conexao=Conectar();
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	char Selecionar[1024];
	sprintf(Selecionar, "SELECT Regiao.Nome FROM Regiao, Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao=Regiao.ID;", ID);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	strcpy(Regiao,"");
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		sprintf(Regiao,"%s %s ",Regiao, Linhas[0]);
	}

	mysql_close(&Conexao);

}

int Checar_Nome(char Nome[30]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Programa_De_TV where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}

void Retorna_Dados_Programa_V(char ID[], char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], char String_Regioes[]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	
	Conexao=Conectar();

	char Selecionar[1024];

	sprintf(Selecionar,	"SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV where Nome='%s';", Nome);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
    while((Linhas=mysql_fetch_row(Resp))!=NULL){
    	strcpy(ID, Linhas[0]);
    	Listar_Regiao(Linhas[0], String_Regioes);
		strcpy(Nome,Linhas[1]);
		strcpy(Emissora,Linhas[2]);
		strcpy(H_Inicial,Linhas[3]);
		strcpy(H_Final,Linhas[4]);
		strcpy(Ibope,Linhas[5]);
		strcpy(Tema,Linhas[6]);
	}
	mysql_close(&Conexao);
}

void Retorna_Dados_Programa(int ID, char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], char String_Regioes[]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	
	Conexao=Conectar();

	char Selecionar[1024];

	sprintf(Selecionar,	"SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV where ID='%i';", ID);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
    while((Linhas=mysql_fetch_row(Resp))!=NULL){
    	Listar_Regiao(Linhas[0], String_Regioes);
		strcpy(Nome,Linhas[1]);
		strcpy(Emissora,Linhas[2]);
		strcpy(H_Inicial,Linhas[3]);
		strcpy(H_Final,Linhas[4]);
		strcpy(Ibope,Linhas[5]);
		strcpy(Tema,Linhas[6]);
	}
	mysql_close(&Conexao);

}

