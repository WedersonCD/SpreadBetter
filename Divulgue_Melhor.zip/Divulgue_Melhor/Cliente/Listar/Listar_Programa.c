WINDOW *Listar_Programa;

void Listar_Regiao(char ID[], char Regioes[]);
int Checar_Data(char Nome[]);

int L_Programa(){

	int Ordem=0, Seta=0;
	Listar_Programa=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);
	init_pair(5,COLOR_WHITE,COLOR_RED);

	keypad(Listar_Programa, TRUE);
	wbkgd(Listar_Programa,COLOR_PAIR(1));

	int x;
	int Y;
	int Tecla;
	char Regioes[30]="";
	

	mvwprintw(Listar_Programa,2,0,"______________________________________________________________________________________________________________________________________________________");
	mvwprintw(Listar_Programa,4,58,"Lista de programas");
	mvwprintw(Listar_Programa,6,54,"1-Organizar lista por Nome");
	mvwprintw(Listar_Programa,7,53,"2-Organizar lista por Emissora");
	mvwprintw(Listar_Programa,8,49,"3-Organizar lista por Horario de inicio");
	mvwprintw(Listar_Programa,9,48,"4-Organizar lista por Horario de terminio");
	mvwprintw(Listar_Programa,10,53,"5-Organizar lista por Ibope");	
	mvwprintw(Listar_Programa,11,53,"6-Organizar lista por Tema");
	mvwprintw(Listar_Programa,12,53,"0-Retornar ao menu anterior");
	wattron(Listar_Programa,COLOR_PAIR(2));
	mvwprintw(Listar_Programa,14,44,"Pressione o numero correspondente a opção desejada");
	wattroff(Listar_Programa,COLOR_PAIR(2));
	wattron(Listar_Programa,COLOR_PAIR(2));
	mvwprintw(Listar_Programa,11,2,"PROGRAMAS EM VERMELHO NAO ESTAO");
	mvwprintw(Listar_Programa,12,7,"COM O IBOPE ATUALIZADOS");
	mvwprintw(Listar_Programa,11,112,"Legenda:");
	mvwprintw(Listar_Programa,12,112,"S-Sul");
	mvwprintw(Listar_Programa,12,124,"N-Norte");
	mvwprintw(Listar_Programa,13,112,"SD-Sudeste");
	mvwprintw(Listar_Programa,13,124,"ND-Nordeste");
	mvwprintw(Listar_Programa,14,112,"CO-Centro_Oeste");
	wattroff(Listar_Programa,COLOR_PAIR(2));
	int Laco=0;
	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;

	Conexao=Conectar();
	do{
		mvwprintw(Listar_Programa,16,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Listar_Programa,17,5,"|Nome do programa           |Emissora                   |H_Inicial |H_Final |Ibope  |Tema Do Programa      |Regioes alcançadas       |");
		mvwprintw(Listar_Programa,18,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
	

		
		if(Ordem==1){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV ORDER BY Nome;");
		}else if(Ordem==2){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV ORDER BY Emissora;");
		}else if(Ordem==3){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV ORDER BY H_Inicial;");
		}else if(Ordem==4){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV ORDER BY H_Final;");
		}else if(Ordem==5){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV ORDER BY Ibope DESC;");
		}else if(Ordem==6){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV ORDER BY Tema;");
		}else if(Ordem==0){
			mysql_query(&Conexao, "SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV;");
		}
		Resp=mysql_store_result(&Conexao);
		x=19;
		Y;
		int Aux=0;
		int Aux2=0;
		while((Linhas=mysql_fetch_row(Resp))!=NULL){
			if(Checar_Data(Linhas[1])==1)mvwprintw(Listar_Programa,x,5,"|                           |                           |          |        |       |                      |                          |");
			Aux2++;
			if(Aux>=Seta){
				if(Checar_Data(Linhas[1])==1)wattron(Listar_Programa,COLOR_PAIR(4));
				else{
					 wattron(Listar_Programa,COLOR_PAIR(5));
					 mvwprintw(Listar_Programa,x,5,"|                           |                           |          |        |       |                      |                          |");
				}

				
					for (Y=1;Y<mysql_num_fields(Resp);Y++){
						switch(Y){
							case 1:
							mvwprintw(Listar_Programa,x,6,"%s",Linhas[Y]);
							break;
							case 2:
							mvwprintw(Listar_Programa,x,34,"%s",Linhas[Y]);
							break;
							case 3:
							mvwprintw(Listar_Programa,x,62,"%s",Linhas[Y]);
							break;
							case 4:
							mvwprintw(Listar_Programa,x,73,"%s",Linhas[Y]);
							break;
							case 5:
							mvwprintw(Listar_Programa,x,82,"%s",Linhas[Y]);
							break;
							case 6:
							mvwprintw(Listar_Programa,x,90,"%s",Linhas[Y]);
						}

					}
				Listar_Regiao(Linhas[0], Regioes);
				mvwprintw(Listar_Programa,x,113,Regioes);

				if(Checar_Data(Linhas[1])==1)wattroff(Listar_Programa,COLOR_PAIR(4));
				else wattroff(Listar_Programa,COLOR_PAIR(5));

				strcpy(Regioes, "");

				x++;

				mvwprintw(Listar_Programa,x,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
				x++;

			}
			Aux++;

		}
		Tecla=wgetch(Listar_Programa);


		if(Tecla==KEY_DOWN){
			if((Aux2-Seta)>=12)
			Seta++;
		}else if(Tecla==KEY_UP){
			if(Seta!=0)
			Seta--;
			mvwprintw(Listar_Programa,5,50,"                                                       ");

		}else if(Tecla=='1'){
			Ordem=1;
			mvwprintw(Listar_Programa,5,50, "                                                       ");

		}else if(Tecla=='2'){
			Ordem=2;
			mvwprintw(Listar_Programa,5,50, "                                                       ");

		}else if(Tecla=='3'){
			Ordem=3;
			mvwprintw(Listar_Programa,5,50, "                                                       ");

		}else if(Tecla=='4'){
			Ordem=4;
			mvwprintw(Listar_Programa,5,50, "                                                       ");

		}else if(Tecla=='5'){
			Ordem=5;
			mvwprintw(Listar_Programa,5,50, "                                                       ");

		}else if(Tecla=='6'){
			Ordem=6;
			mvwprintw(Listar_Programa,5,50, "                                                       ");

		}else if(Tecla=='0'){
			Laco=1;
		}else{
			wattron(Listar_Programa,COLOR_PAIR(3));
			mvwprintw(Listar_Programa,5,50, "POR FAVOR, PRESSIONE UM NUMERO VALIDO");
			wattroff(Listar_Programa,COLOR_PAIR(3));
		}
	}while(Laco==0);
     mysql_close(&Conexao);

	return 1;

	wrefresh(Listar_Programa);
	delwin(Listar_Programa);
}
