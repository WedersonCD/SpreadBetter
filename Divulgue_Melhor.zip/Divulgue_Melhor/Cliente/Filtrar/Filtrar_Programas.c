WINDOW *Filtrar_Programas;
void Filtro(char Tema[], int Ideal[][5]);
int Certifica(char Tema[]);
void Retorna_Temas(char M[][20]);
int Verifica_Tema(char Tema[]);
int N_Linhas();
int N_Linhas_E(char Tema[]);
void Tabela(int ID);
void Retorna_Dados_Programa(int ID, char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], char String_Regioes[]);

void Limpar(){

for(int x=0;x<140;x++){
	for(int y=0;y<150;y++){
		mvwprintw(Filtrar_Programas,x,y," ");
		}	
	}
}

int F_Programas(){

	int ID=0;
	int Soma=0;
	char Nome[32];
	Filtrar_Programas=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);


	wbkgd(Filtrar_Programas,COLOR_PAIR(1));
	char Tema[20];
	if(Certifica(Tema)==0)return 1;
	Limpar();
	int L=N_Linhas_E(Tema);
	int Ideal[L][5];



	
	for(int x=0;x<L;x++){
		for(int y=0;y<5;y++)
			Ideal[x][y]=0;
	}
	
	Filtro(Tema, Ideal);
	
	int Total=0;
	for(int x=0;x<L;x++){
		Total=0;
		for(int y=1;y<5;y++){
			Total=Ideal[x][y]+Total;
		}
		if(Total>Soma){
			Soma=Total;
			ID=Ideal[x][0];
		}
	}

	Retorna_Dados(ID, Nome);
	mvwprintw(Filtrar_Programas,10,0,"______________________________________________________________________________________________________________________________________________________");
	mvwprintw(Filtrar_Programas,12,60,"DIVULGUE MELHOR");
	wattron(Filtrar_Programas,COLOR_PAIR(2));
	mvwprintw(Filtrar_Programas,14,10,"O programa de TV mais recomendado é o");
	mvwprintw(Filtrar_Programas,14,strlen(Nome)+52,"pois dentre os programas do tema");  
	mvwprintw(Filtrar_Programas,14,strlen(Nome)+strlen(Tema)+86,"ele eh o que mais se\n destaca nas categorias:Maior ibope, Duração do programa, Popularidade da emissora e Abrangencia de trasmissão.");
	wattroff(Filtrar_Programas,COLOR_PAIR(2));
	wattron(Filtrar_Programas,COLOR_PAIR(4));
	mvwprintw(Filtrar_Programas,14,50,"%s",Nome);
	mvwprintw(Filtrar_Programas,14,strlen(Nome)+85,"%s",Tema);
	wattroff(Filtrar_Programas,COLOR_PAIR(4));

	mvwprintw(Filtrar_Programas,16,50,"Pressione qualquer tecla para concluir");
	Tabela(ID);

	char Tecla;
	Tecla=wgetch(Filtrar_Programas);

	return 1;
}

	
void Tabela(int ID){		
		
	char Nome[26]="";
	char Emissora[26]="";
	char H_Inicial[8]="";
	char H_Final[8]="";
	char Ibope[3]="";
	char Tema[20]="";
	char String_Regioes[100]="";

	Retorna_Dados_Programa(ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, String_Regioes);

	mvwprintw(Filtrar_Programas,19,60,"Dados do programa");
	mvwprintw(Filtrar_Programas,20,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
	mvwprintw(Filtrar_Programas,21,5,"|Nome do programa           |Emissora                   |H_Inicial |H_Final |Ibope  |Tema Do Programa      |Regioes alcançadas        |");
	mvwprintw(Filtrar_Programas,22,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
	mvwprintw(Filtrar_Programas,23,5,"|                           |                           |          |        |       |                      |                          |");
	mvwprintw(Filtrar_Programas,24,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		
	wattron(Filtrar_Programas,COLOR_PAIR(4));
	mvwprintw(Filtrar_Programas,23,6,"%s",Nome);
	mvwprintw(Filtrar_Programas,23,34,"%s",Emissora);
	mvwprintw(Filtrar_Programas,23,62,"%s",H_Inicial);
	mvwprintw(Filtrar_Programas,23,73,"%s",H_Final);
	mvwprintw(Filtrar_Programas,23,82,"%s",Ibope);
	mvwprintw(Filtrar_Programas,23,90,"%s",Tema);
	mvwprintw(Filtrar_Programas,23,113,"%s",String_Regioes);
	wattroff(Filtrar_Programas,COLOR_PAIR(4));

}

int Certifica(char Tema[]){
	int Aux=0;
	int L=N_Linhas();
	char Temas[L][20];
	int x;
	Retorna_Temas(Temas);
	mvwprintw(Filtrar_Programas,21,5,"+---------------------------------------------------------------------------------------------------------------------------------------+");
	mvwprintw(Filtrar_Programas,22,5,"|                                                                                                                                       |");
	mvwprintw(Filtrar_Programas,23,5,"+---------------------------------------------------------------------------------------------------------------------------------------+");
	mvwprintw(Filtrar_Programas,22,60,"Lista de temas");
	int O=24;
	int C=7;
	
	for(x=0;x<L;x++){
		if(x>10){
			if((x%11)==0){O=24; C=C+24;}
			wattron(Filtrar_Programas,COLOR_PAIR(4));
			mvwprintw(Filtrar_Programas,O,C,"%s",Temas[x]);
			wattroff(Filtrar_Programas,COLOR_PAIR(4));

		}else{
			mvwprintw(Filtrar_Programas,O,5,"|");
			wattron(Filtrar_Programas,COLOR_PAIR(4));
			mvwprintw(Filtrar_Programas,O,C,"%s",Temas[x]);
			wattroff(Filtrar_Programas,COLOR_PAIR(4));
			mvwprintw(Filtrar_Programas,O,141,"|");
		}
		O++;
	}
	mvwprintw(Filtrar_Programas,34,5,"+---------------------------------------------------------------------------------------------------------------------------------------+");

	while(Aux==0){
		mvwprintw(Filtrar_Programas,15,60,"                              ");
		mvwprintw(Filtrar_Programas,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Filtrar_Programas,12,60,"ESCOLHA TEMA");
		wattron(Filtrar_Programas,COLOR_PAIR(2));
		mvwprintw(Filtrar_Programas,14,20,"Digite o nome do tema que mais corresponde ao publico alvo do seu produto ou insira 0 e aperte enter.");
		wattroff(Filtrar_Programas,COLOR_PAIR(2));
		mvwprintw(Filtrar_Programas,17,0,"______________________________________________________________________________________________________________________________________________________");


		mvwprintw(Filtrar_Programas,15,60,"");
		wattron(Filtrar_Programas,COLOR_PAIR(4));
		wgetstr(Filtrar_Programas, Tema);
		wattroff(Filtrar_Programas,COLOR_PAIR(4));



		if(strlen(Tema)==1 && Tema[0]=='0'){
			return 0;
		}else if(Verifica_Tema(Tema)==0){
			wattron(Filtrar_Programas,COLOR_PAIR(3));
			mvwprintw(Filtrar_Programas,13,56, "TEMA NAO ENCONTRADO");
			wattroff(Filtrar_Programas,COLOR_PAIR(3));
		}else{
			Aux++;
		}
		mvwprintw(Filtrar_Programas,15,70,"                                          ");
	}
	mvwprintw(Filtrar_Programas,14,35,"                                                                                         ");
	mvwprintw(Filtrar_Programas,13,10,"                                                                                                                                                                   ");
	return 1;
}