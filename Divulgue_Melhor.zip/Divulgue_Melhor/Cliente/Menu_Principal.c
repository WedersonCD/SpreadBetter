#include "Listar/Listar_Programa.c" 
#include "Listar/Listar_Emissora.c" 
#include "Filtrar/Filtrar_Programas.c"
#include "Visualizar/Visualizar_Programa.c"
	WINDOW *Menu_Principal;

void Limpar_M(){
for(int x=0;x<140;x++){
	for(int y=0;y<150;y++){
		mvwprintw(Menu_Principal,x,y," ");
		}	
	}
}

void M_Principal(){

	Menu_Principal=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);


	wbkgd(Menu_Principal,COLOR_PAIR(1));
	char Tecla='0';
	int Aux=0;
	while(1){
	Limpar_M();
		mvwprintw(Menu_Principal,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Menu_Principal,12,60,"MENU PRINCIPAL");
		mvwprintw(Menu_Principal,15,58,"1-Iniciar Filtro");
		mvwprintw(Menu_Principal,16,54,"2-Listar todas emissoras");
		mvwprintw(Menu_Principal,17,54,"3-Listar todos Programas");
		mvwprintw(Menu_Principal,18,52,"4-Visualizar programa especifico");

		wattron(Menu_Principal,COLOR_PAIR(2));
		mvwprintw(Menu_Principal,21,44,"Pressione o numero correspondente a opção desejada");
		wattroff(Menu_Principal,COLOR_PAIR(2));
		mvwprintw(Menu_Principal,23,0,"_______________________________________________________________________________________________________________________________________________________");
		Tecla=wgetch(Menu_Principal);
			if(Tecla=='1'){
				Aux=F_Programas();
			}else if(Tecla=='2'){
				Aux=L_Emissora();
			}else if(Tecla=='3'){
				Aux=L_Programa();
			}else if(Tecla=='4'){
				Aux=V_Programa();
			}else{
				wattron(Menu_Principal,COLOR_PAIR(3));
				mvwprintw(Menu_Principal,19,50, "POR FAVOR, PRESSIONE UM NUMERO VALIDO");
				wattroff(Menu_Principal,COLOR_PAIR(3));
			}
	}

	wrefresh(Menu_Principal);
	delwin(Menu_Principal);

}
