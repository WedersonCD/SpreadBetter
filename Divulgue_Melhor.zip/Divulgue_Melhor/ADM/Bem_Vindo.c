WINDOW *Bem_Vindo;

int B_Vindo(){

	Bem_Vindo=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);

	wbkgd(Bem_Vindo,COLOR_PAIR(1));
	mvwprintw(Bem_Vindo,8,  0,"______________________________________________________________________________________________________________________________________________________");
	mvwprintw(Bem_Vindo,10, 30," ____    ______   __  __    __      __  _____   _   _   _____     ____  ");
	mvwprintw(Bem_Vindo,11, 30,"|  _ \\  |  ____| |  \\/  |   \\ \\    / / |_   _| | \\ | | |  __ \\   / __ \\ ");
	mvwprintw(Bem_Vindo,12, 30,"| |_) | | |__    | \\  / |    \\ \\  / /    | |   |  \\| | | |  | | | |  | |");
	mvwprintw(Bem_Vindo,13, 30,"|  _ <  |  __|   | |\\/| |     \\ \\/ /     | |   | . ` | | |  | | | |  | |");
	mvwprintw(Bem_Vindo,14, 30,"| |_) | | |____  | |  | |      \\  /     _| |_  | |\\  | | |__| | | |__| |");
	mvwprintw(Bem_Vindo,15, 30,"|____/  |______| |_|  |_|       \\/     |_____| |_| \\_| |_____/   \\____/");
	wattron(Bem_Vindo,COLOR_PAIR(2));
	wattron(Bem_Vindo,A_BLINK);
	mvwprintw(Bem_Vindo,25, 45,"Pressione qualquer tecla para continuar");
	wattroff(Bem_Vindo,A_BLINK);
	wattroff(Bem_Vindo,COLOR_PAIR(2));
	mvwprintw(Bem_Vindo,27,  0,"______________________________________________________________________________________________________________________________________________________");

	wgetch(Bem_Vindo);
	delwin(Bem_Vindo);

}





     
     
     
     
     
      
                                                                             
                                                                             

                                                                   
                                                                             

