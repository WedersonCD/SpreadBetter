#include <stdio.h>
#include <curses.h>
#include <mysql/mysql.h>
#include <string.h>
#include <time.h>
#include "Conectar.c"

int N_Linhas(){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	mysql_query(&Conexao,"SELECT Nome FROM Programa_De_TV;");
	Resp=mysql_store_result(&Conexao);
	int L=0;
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		L++;
	}
	mysql_close(&Conexao);
	return L;
}

void Retorna_Nomes(char M[][30], char From[]){

	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	char Selecionar[200];
	sprintf(Selecionar,"SELECT Nome FROM %s;",From);
	mysql_query(&Conexao,Selecionar);
	Resp=mysql_store_result(&Conexao);
	int Aux=0;
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		strcpy(M[Aux],Linhas[0]);
		Aux++;
	}
	mysql_close(&Conexao);

}

void Criar_Tabela(WINDOW *Tabela, int O, char From[]){

	int L=N_Linhas();
	char Nomes[L][30];
	int x;
	Retorna_Nomes(Nomes, From);
	mvwprintw(Tabela,O,5,"+---------------------------------------------------------------------------------------------------------------------------------------+");
	mvwprintw(Tabela,O+1,5,"|                                                                                                                                       |");
	mvwprintw(Tabela,O+2,5,"+---------------------------------------------------------------------------------------------------------------------------------------+");
	mvwprintw(Tabela,O+1,60,"Lista de %s", From);
	int C=7;
	int Lc=O+3;
	for(x=0;x<L;x++){
		if(x>15){
			if((x%16)==0){Lc=O+3; C=C+30;}
			wattron(Tabela,COLOR_PAIR(4));
			mvwprintw(Tabela,Lc,C,"%s",Nomes[x]);
			wattroff(Tabela,COLOR_PAIR(4));

		}else{
			mvwprintw(Tabela,Lc,5,"|");
			wattron(Tabela,COLOR_PAIR(4));
			mvwprintw(Tabela,Lc,C,"%s",Nomes[x]);
			wattroff(Tabela,COLOR_PAIR(4));
			mvwprintw(Tabela,Lc,141,"|");
		}
		Lc++;
	}
	mvwprintw(Tabela,O+19,5,"+---------------------------------------------------------------------------------------------------------------------------------------+");
}


#include "Bem_Vindo.c"
#include "Menu_Principal.c"


int main(){

	Conectar();

	initscr();
	start_color();
	B_Vindo();
	M_Principal();
	endwin();
	return 0;

}


