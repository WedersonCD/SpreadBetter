#define SVD "localhost"
#define USR "root"
#define PSW "wederson"
#define BD  "Divulgue_melhor"

MYSQL Conectar(){
	MYSQL Conexao;
	int Erro;


	mysql_init(&Conexao);
	if(mysql_real_connect(&Conexao, SVD, USR, PSW, BD, 0, NULL, 0)){
		
	}else{
		printf("\nFalha de Conexao\n");
		printf("Erro %d : %s\n", mysql_errno(&Conexao), mysql_error(&Conexao));
	}

	return Conexao;

}