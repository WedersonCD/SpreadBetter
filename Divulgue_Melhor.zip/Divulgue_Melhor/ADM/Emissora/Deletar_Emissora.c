#include "Deletar_Confirmar.c"

int Al_Emissora_Menu(char Nome[30], char Tipo[6]);
int Confirmar_Nome(char Nome[30]);
char Retorna_Dados_Deletar(char Nome[30]);
int Del_Confirmar(char Nome[30], char Tipo[6]);

WINDOW *Deletar_Emissora;


char Del_Emissora(){
	Deletar_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Deletar_Emissora,COLOR_PAIR(1));

	char Nome[30];

	while(1){
		mvwprintw(Deletar_Emissora,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Deletar_Emissora,12,62,"DELETAR EMISSORA");
		wattron(Deletar_Emissora,COLOR_PAIR(2));
		mvwprintw(Deletar_Emissora,14,35,"Digite o nome da emissora que desejas deletar ou digite 0 e aperte enter");
		wattroff(Deletar_Emissora,COLOR_PAIR(2));
		mvwprintw(Deletar_Emissora,16,0,"______________________________________________________________________________________________________________________________________________________");

		mvwprintw(Deletar_Emissora,15,70,"");
		wattron(Deletar_Emissora,COLOR_PAIR(4));
		wgetstr(Deletar_Emissora, Nome);
		wattroff(Deletar_Emissora,COLOR_PAIR(4));

		if(Nome[0]=='0'){
			O_Emissora();
		}else if(Confirmar_Nome(Nome)==0){
			wattron(Deletar_Emissora,COLOR_PAIR(3));
			mvwprintw(Deletar_Emissora,13,60, "EMISSORA NAO ENCONTRADA");
			wattroff(Deletar_Emissora,COLOR_PAIR(3));
		}else{
			Retorna_Dados_Deletar(Nome);

		}
		mvwprintw(Deletar_Emissora,15,70,"                                          ");

	}
	return 0;

}

char Retorna_Dados_Deletar(char Nome[30]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	
	Conexao=Conectar();

	char Selecionar[1024];
	sprintf(Selecionar,	"SELECT * FROM Emissoras where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	Linhas=mysql_fetch_row(Resp);

	char Tipo[6];
	sprintf(Tipo, "%s",Linhas[2]);

	mysql_close(&Conexao);

	Del_Confirmar(Nome, Tipo);
}


