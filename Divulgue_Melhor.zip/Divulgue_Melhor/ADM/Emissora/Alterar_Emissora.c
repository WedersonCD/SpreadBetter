#include "Alterar_Emissora_Menu.c"

int Al_Emissora_Menu(char Nome[30], char Tipo[6]);
int Confirmar_Nome(char Nome[30]);
char Retorna_Dados(char Nome[30]);

WINDOW *Alterar_Emissora;


char Al_Emissora(){
	Alterar_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Alterar_Emissora,COLOR_PAIR(1));

	char Nome[30];

	while(1){
		mvwprintw(Alterar_Emissora,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Alterar_Emissora,12,60,"ALTERAR DADOS EMISSORA");
		wattron(Alterar_Emissora,COLOR_PAIR(2));
		mvwprintw(Alterar_Emissora,14,35,"Digite o nome da emissora cujos dados desejas alterar ou digite 0 e aperte enter");
		wattroff(Alterar_Emissora,COLOR_PAIR(2));
		mvwprintw(Alterar_Emissora,16,0,"______________________________________________________________________________________________________________________________________________________");

		mvwprintw(Alterar_Emissora,15,70,"");
		wattron(Alterar_Emissora,COLOR_PAIR(4));
		wgetstr(Alterar_Emissora, Nome);
		wattroff(Alterar_Emissora,COLOR_PAIR(4));

		if(Nome[0]=='0'){
			O_Emissora();
		}else if(Confirmar_Nome(Nome)==0){
			wattron(Alterar_Emissora,COLOR_PAIR(3));
			mvwprintw(Alterar_Emissora,13,60, "EMISSORA NAO ENCONTRADA");
			wattroff(Alterar_Emissora,COLOR_PAIR(3));
		}else{
			Retorna_Dados(Nome);

		}
		mvwprintw(Alterar_Emissora,15,70,"                                          ");

	}
	return 0;

}

char Retorna_Dados(char Nome[30]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	
	Conexao=Conectar();

	char Selecionar[1024];
	sprintf(Selecionar,	"SELECT * FROM Emissoras where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	Linhas=mysql_fetch_row(Resp);

	char Tipo[6];
	sprintf(Tipo, "%s",Linhas[2]);

	mysql_close(&Conexao);

	Al_Emissora_Menu(Nome, Tipo);

}