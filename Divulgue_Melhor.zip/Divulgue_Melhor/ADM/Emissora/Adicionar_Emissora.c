#include "Adicionar_Emissora_Tipo.c"

WINDOW *Add_Emissora;
int T_Emissora(char Nome[30]);
int A_Emissora(){

	Add_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Add_Emissora,COLOR_PAIR(1));
	char Nome[40]="";
	char  Tipo;
	int Aux=0;
	do{
		mvwprintw(Add_Emissora,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Add_Emissora,12,60,"ADICIONAR NOVA EMISSORA");
		mvwprintw(Add_Emissora,15,50,"+---------------------------+--------------------+");
		mvwprintw(Add_Emissora,16,50,"|NOME DA EMISSORA           |TIPO DE SINAL       |");
		mvwprintw(Add_Emissora,17,50,"+---------------------------+--------------------+");
		mvwprintw(Add_Emissora,18,50,"|                           |                    |");
		mvwprintw(Add_Emissora,19,50,"+---------------------------+--------------------+");
		mvwprintw(Add_Emissora,29,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Add_Emissora,21,71,"NOME");
		wattron(Add_Emissora,COLOR_PAIR(2));
		mvwprintw(Add_Emissora,23,40,"Insira o nome da emissora ou insira 0 para cancelar e tecle ENTER");
		
		wattroff(Add_Emissora,COLOR_PAIR(2));
		mvwprintw(Add_Emissora,25,70,"");
		wattron(Add_Emissora,COLOR_PAIR(4));
		wgetstr(Add_Emissora, Nome);
		wattroff(Add_Emissora,COLOR_PAIR(4));

		if(strlen(Nome)>25){	
			wattron(Add_Emissora,COLOR_PAIR(3));
			mvwprintw(Add_Emissora,22,58,"O NOME DEVE CONTER MENOS DE 26 LETRAS");
			wattroff(Add_Emissora,COLOR_PAIR(3));
			mvwprintw(Add_Emissora,25,70,"                                                                 ");

		}else Aux++;

	}while(Aux==0);
		if(strlen(Nome)==1 && Nome[0]=='0'){
			O_Emissora();
			delwin(Add_Emissora);
		}else{
			T_Emissora(Nome);
		}

	wrefresh(Add_Emissora);
	delwin(Add_Emissora);

	return (0);
}

