WINDOW *Listar_Emissora;

int O_Emissora();

int L_Emissora(int Ordem, int Seta){

	Listar_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	keypad(Listar_Emissora, TRUE);
	wbkgd(Listar_Emissora,COLOR_PAIR(1));

	int x;
	int Y;
	int Tecla;
	

	mvwprintw(Listar_Emissora,2,0,"______________________________________________________________________________________________________________________________________________________");
	mvwprintw(Listar_Emissora,4,55,"Lista de todas emissoras",Seta);
	mvwprintw(Listar_Emissora,6,54,"1-Organizar lista por nome");
	mvwprintw(Listar_Emissora,8,50,"2-Organizar lista por tipo de sinal");
	mvwprintw(Listar_Emissora,10,53,"0-Retornar ao menu anterior");
	wattron(Listar_Emissora,COLOR_PAIR(2));
	mvwprintw(Listar_Emissora,11,44,"Pressione o numero correspondente a opção desejada");
	wattroff(Listar_Emissora,COLOR_PAIR(2));

	do{
		mvwprintw(Listar_Emissora,12,48,"+----------------------+--------------------+");
		mvwprintw(Listar_Emissora,13,48,"|NOME DA EMISSORA      |TIPO DE SINAL       |");
		mvwprintw(Listar_Emissora,14,48,"+----------------------+--------------------+");

		MYSQL Conexao;
		MYSQL_RES *Resp;
		MYSQL_ROW Linhas;

		Conexao=Conectar();
		
		if(Ordem==1){
			mysql_query(&Conexao, "SELECT * FROM Emissoras ORDER BY Nome;");
			//sprintf(Selecionar,"SELECT * FROM Emissoras ORDER BY Nome;");
		}else if(Ordem==2){
			mysql_query(&Conexao, "SELECT * FROM Emissoras ORDER BY Disponibilidade;");
			//sprintf(Selecionar,"SELECT * FROM Emissoras ORDER BY Disponibilidade;");
		}else if(Ordem==0){
			mysql_query(&Conexao, "SELECT * FROM Emissoras;");
			//sprintf(Selecionar,"SELECT * FROM Emissoras;");
		}
		Resp=mysql_store_result(&Conexao);
		x=15;
		Y;
		int Aux=0;
		int Aux2=0;
		while((Linhas=mysql_fetch_row(Resp))!=NULL){
			Aux2++;
			if(Aux>=Seta){
				mvwprintw(Listar_Emissora,x,48,"|                      |                    |");
				wattron(Listar_Emissora,COLOR_PAIR(4));
				
					for (Y=1;Y<mysql_num_fields(Resp);Y++){
						wattron(Listar_Emissora,COLOR_PAIR(4));
						switch(Y){
							case 1:
							mvwprintw(Listar_Emissora,x,49,"%s",Linhas[Y]);
							break;
							case 2:
							mvwprintw(Listar_Emissora,x,74,"%s",Linhas[Y]);
						}
					}


				wattroff(Listar_Emissora,COLOR_PAIR(4));

				x++;

				mvwprintw(Listar_Emissora,x,48,"+----------------------+--------------------+");
				x++;

			}
			Aux++;

		}
		Tecla=wgetch(Listar_Emissora);

     	mysql_close(&Conexao);

		if(Tecla==KEY_DOWN){
			if((Aux2-Seta)>=15)
			Seta++;
			L_Emissora(Ordem, Seta);
		}else if(Tecla==KEY_UP){
			if(Seta!=0)
			Seta--;
			L_Emissora(Ordem, Seta);
		}else if(Tecla=='1'){
			wrefresh(Listar_Emissora);
			delwin(Listar_Emissora);
			L_Emissora(1,0);

		}else if(Tecla=='2'){
			wrefresh(Listar_Emissora);
			delwin(Listar_Emissora);
			L_Emissora(2,0);
			
		}else if(Tecla=='0'){
			wrefresh(Listar_Emissora);
			delwin(Listar_Emissora);
			O_Emissora();
			
		}else{
			wattron(Listar_Emissora,COLOR_PAIR(3));
			mvwprintw(Listar_Emissora,5,50, "POR FAVOR, PRESSIONE UM NUMERO VALIDO");
			wattroff(Listar_Emissora,COLOR_PAIR(3));
			}
	}while(Tecla!='1','2','0',KEY_UP,KEY_DOWN);

	//wgetch(Listar_Emissora);
	wrefresh(Listar_Emissora);
	delwin(Listar_Emissora);
}
