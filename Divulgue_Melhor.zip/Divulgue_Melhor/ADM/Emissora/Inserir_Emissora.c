int Confirmar_Nome(char Nome[30]);

int Inserir_Emissora(char Nome[30], char Tipo[6]){
	
	MYSQL Conexao;
	Conexao=Conectar();


	if(Confirmar_Nome(Nome)==0){
		char Q_Insert[80];
		sprintf(Q_Insert, "INSERT INTO Emissoras(Nome, Disponibilidade) VALUES('%s', '%s');",Nome,Tipo);
		mysql_query(&Conexao, Q_Insert);
		mysql_close(&Conexao);

		return '1';
	}else{
		return '0';
	}
		

}

int Confirmar_Nome(char Nome[30]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Emissoras where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}