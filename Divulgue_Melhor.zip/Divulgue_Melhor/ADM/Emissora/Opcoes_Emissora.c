#include "Listar_Emissora.c"
#include "Alterar_Emissora.c"
#include "Adicionar_Emissora.c"
#include "Deletar_Emissora.c"


int L_Emissora(int Ordem, int Seta);
int A_Emissora();
char Al_Emissora();
int M_Principal();
char Del_Emissora();

WINDOW *Opcoes_Emissora;

int O_Emissora(){

	Opcoes_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);


	wbkgd(Opcoes_Emissora,COLOR_PAIR(1));
	char Tecla;
	do{
		mvwprintw(Opcoes_Emissora,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Opcoes_Emissora,12,50,"Opcoes relacionadas a emissoras");
		mvwprintw(Opcoes_Emissora,14,44,"1-Visualizar lista de todas emissoras já inseridas");
		mvwprintw(Opcoes_Emissora,16,53,"2-Adicionar nova emissora");
		mvwprintw(Opcoes_Emissora,18,48,"3-Alterar dados de emissora já inseridas");
		mvwprintw(Opcoes_Emissora,20,52,"4-Remover emissora já inseridas");
		mvwprintw(Opcoes_Emissora,22,53,"0-Retornar ao menu principal.");


		wattron(Opcoes_Emissora,COLOR_PAIR(2));
		mvwprintw(Opcoes_Emissora,26,44,"Pressione o numero correspondente a opção desejada");
		wattroff(Opcoes_Emissora,COLOR_PAIR(2));
		mvwprintw(Opcoes_Emissora,28,0,"______________________________________________________________________________________________________________________________________________________");

		Tecla=wgetch(Opcoes_Emissora);
			if(Tecla=='1'){
				L_Emissora(0, 0);
			}else if(Tecla=='0'){
				M_Principal();
			}else if(Tecla=='2'){
				A_Emissora();
			}else if(Tecla=='3'){
				Al_Emissora();
			}else if(Tecla=='4'){
				Del_Emissora();
			}else{
				wattron(Opcoes_Emissora,COLOR_PAIR(3));
				mvwprintw(Opcoes_Emissora,24,50, "POR FAVOR, PRESSIONE UM NUMERO VALIDO");
				wattroff(Opcoes_Emissora,COLOR_PAIR(3));
			}
	}while(Tecla!='1' || Tecla!='2');

	wrefresh(Opcoes_Emissora);
	delwin(Opcoes_Emissora);

}