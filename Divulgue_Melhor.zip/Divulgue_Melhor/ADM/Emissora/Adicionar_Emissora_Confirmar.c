#include "Inserir_Emissora.c"

int A_Emissora();
int O_Emissora();

WINDOW *Confirmar_Emissora, *Confirmado;


int C(int x);
int Confirma_Nome();

char Adicionar_Emissora_Confirmar(char Nome[40], char Tipo[6]){

	Confirmar_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Confirmar_Emissora,COLOR_PAIR(1));
	char Alternativa;
	do{

		
		mvwprintw(Confirmar_Emissora,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Confirmar_Emissora,12,60,"ADICIONAR NOVA EMISSORA");
		mvwprintw(Confirmar_Emissora,15,50,"+---------------------------+--------------------+");
		mvwprintw(Confirmar_Emissora,16,50,"|NOME DA EMISSORA           |TIPO DE SINAL       |");
		mvwprintw(Confirmar_Emissora,17,50,"+---------------------------+--------------------+");
		mvwprintw(Confirmar_Emissora,18,50,"|                           |                    |");
		mvwprintw(Confirmar_Emissora,19,50,"+---------------------------+--------------------+");
		mvwprintw(Confirmar_Emissora,35,0,"______________________________________________________________________________________________________________________________________________________");
		
		wattron(Confirmar_Emissora,COLOR_PAIR(4));
		mvwprintw(Confirmar_Emissora,18,51,"%s",Nome);
		mvwprintw(Confirmar_Emissora,18,79,"%s",Tipo);
		wattroff(Confirmar_Emissora,COLOR_PAIR(4));

		mvwprintw(Confirmar_Emissora,21,68,"CONFIRMACAO");
		wattron(Confirmar_Emissora,COLOR_PAIR(2));
		mvwprintw(Confirmar_Emissora,23,53,"1-Pressione 1 para confirmar a inserção.");
		mvwprintw(Confirmar_Emissora,25,51,"2-Pressione 2 para cancelar e re-inserir os dados.");
		mvwprintw(Confirmar_Emissora,27,40,"3-Pressione 3 para cancelar e retronar ao menu de opções relacionadas a emissora.");
		wattroff(Confirmar_Emissora,COLOR_PAIR(2));

		mvwprintw(Confirmar_Emissora,32,0,"");
		Alternativa=wgetch(Confirmar_Emissora);


		if(Alternativa=='1'){
			if(Inserir_Emissora(Nome, Tipo)=='1'){
				C(1);
				wrefresh(Confirmar_Emissora);
				delwin(Confirmar_Emissora);
			}else if(Inserir_Emissora(Nome, Tipo)=='0'){
				C(0);
				wrefresh(Confirmar_Emissora);
				delwin(Confirmar_Emissora);

			}
			

		}else if(Alternativa=='2'){
			A_Emissora();
			delwin(Confirmar_Emissora);
		}else if(Alternativa=='3'){
			O_Emissora();
			delwin(Confirmar_Emissora);
		}else{
			wattron(Confirmar_Emissora,COLOR_PAIR(3));
			mvwprintw(Confirmar_Emissora,20,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Confirmar_Emissora,COLOR_PAIR(3));

		}

	}while(Alternativa!='1' || Alternativa!='2'|| Alternativa!='3');

	wrefresh(Confirmar_Emissora);
	delwin(Confirmar_Emissora);
}


int C(int x){

	Confirmado=newwin(11,83,20,38);
	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(3,COLOR_GREEN,COLOR_WHITE);

	wbkgd(Confirmado,COLOR_PAIR(1));


	if(x==1){

		wattron(Confirmado,COLOR_PAIR(3));
		mvwprintw(Confirmado,3,18,"EMISSORA INSERIDA COM SUCESSO");
		mvwprintw(Confirmado,6,10,"PRESSIONE QUALQUER TECLA PARA RETORNAR AO MENU");
		wattroff(Confirmado,COLOR_PAIR(3));

		wgetch(Confirmado);
		wrefresh(Confirmado);
		O_Emissora();
		delwin(Confirmado);

	}else{
		wattron(Confirmado,COLOR_PAIR(3));
		mvwprintw(Confirmado,3,18,"ESSE NOME DE EMISSORA JA FOI INSERIDO");
		mvwprintw(Confirmado,6,10,"PRESSIONE QUALQUER TECLA PARA REINSERIR OS DADOS");
		wattroff(Confirmado,COLOR_PAIR(3));
		
		wgetch(Confirmado);
		
		wrefresh(Confirmado);
		A_Emissora();
		delwin(Confirmado);
	}
}