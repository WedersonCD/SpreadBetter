#include "Alterar_Emissora_Nome.c"

WINDOW *Alterar_Emissora_Menu, *Alterar_Nome, *Alterar_Tipo;

char Al_Nome(char Nome[30], char Tipo[6]);
char Al_Tipo(char Nome[30], char Tipo[7]);
int	O_Emissora();
char Atualizar_Emissora(char Nome[30], char Nome_Novo[30]);
int Confirmar_Atualizacao(char Nome[30]);

int Al_Emissora_Menu(char Nome[30], char Tipo[7]){

	Alterar_Emissora_Menu=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Alterar_Emissora_Menu,COLOR_PAIR(1));
	char Alternativa;
	do{

				
		mvwprintw(Alterar_Emissora_Menu,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Alterar_Emissora_Menu,12,60,"ALTERAR DADOS EMISSORA");
		mvwprintw(Alterar_Emissora_Menu,15,47,"+---------------------------+--------------------+");
		mvwprintw(Alterar_Emissora_Menu,16,47,"|NOME DA EMISSORA           |TIPO DE SINAL       |");
		mvwprintw(Alterar_Emissora_Menu,17,47,"+---------------------------+--------------------+");
		mvwprintw(Alterar_Emissora_Menu,18,47,"|                           |                    |");
		mvwprintw(Alterar_Emissora_Menu,19,47,"+---------------------------+--------------------+");
		mvwprintw(Alterar_Emissora_Menu,35,0,"______________________________________________________________________________________________________________________________________________________");
				
		wattron(Alterar_Emissora_Menu,COLOR_PAIR(4));
		mvwprintw(Alterar_Emissora_Menu,18,48,"%s",Nome);
		mvwprintw(Alterar_Emissora_Menu,18,76,"%s",Tipo);
		wattroff(Alterar_Emissora_Menu,COLOR_PAIR(4));

		mvwprintw(Alterar_Emissora_Menu,21,60,"MENU ALTERAR DADOS EMISSORA");
		mvwprintw(Alterar_Emissora_Menu,23,63,"1-Inserir outro nome.");
		mvwprintw(Alterar_Emissora_Menu,25,62,"2-Mudar o tipo de sinal");
		mvwprintw(Alterar_Emissora_Menu,27,47,"0-Retronar ao menu de opções relacionadas a emissoras.");
		wattron(Alterar_Emissora_Menu,COLOR_PAIR(2));
		mvwprintw(Alterar_Emissora_Menu,29,51,"Pressione o numero correspondente a opção desejada");
		wattroff(Alterar_Emissora_Menu,COLOR_PAIR(2));

		mvwprintw(Alterar_Emissora_Menu,32,0,"");
		Alternativa=wgetch(Alterar_Emissora_Menu);


		if(Alternativa=='1'){
			Al_Nome(Nome, Tipo);
		}else if(Alternativa=='2'){
			Al_Tipo(Nome, Tipo);
		}else if(Alternativa=='0'){
			delwin(Alterar_Emissora_Menu);
			O_Emissora();
		}else{
			wattron(Alterar_Emissora_Menu,COLOR_PAIR(3));
			mvwprintw(Alterar_Emissora_Menu,20,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Alterar_Emissora_Menu,COLOR_PAIR(3));

		}

	}while(Alternativa!='1' || Alternativa!='2'|| Alternativa!='3');
}

char Al_Tipo(char Nome[30], char Tipo[6]){

	Alterar_Tipo=newwin(5,70,21,38);
	wborder(Alterar_Tipo, '|', '|', '-', '-', '+', '+', '+', '+');
	wbkgd(Alterar_Tipo,COLOR_PAIR(1));
	MYSQL Conexao;
	Conexao=Conectar();
	char Alterar[100], Novo_Tipo[7];
	if(Tipo[0]=='F'){
		sprintf(Alterar, "UPDATE Emissoras SET Disponibilidade='Aberto' WHERE Nome='%s';", Nome);
		sprintf(Novo_Tipo, "Aberto");
	}else{
		sprintf(Alterar, "UPDATE Emissoras SET Disponibilidade='Fechado' WHERE Nome='%s';", Nome);
		sprintf(Novo_Tipo, "Fechado");
	}
	mysql_query(&Conexao, Alterar);
	mysql_close(&Conexao);


	wattron(Alterar_Tipo,COLOR_PAIR(2));	
	mvwprintw(Alterar_Tipo,1,20,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Tipo,3,15,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Tipo,COLOR_PAIR(2));
	wgetch(Alterar_Tipo);
	delwin(Alterar_Tipo);

	Al_Emissora_Menu(Nome, Novo_Tipo);
}

char Al_Nome(char Nome[30], char Tipo[6]){

	Alterar_Nome=newwin(5,70,21,38);

	
	wborder(Alterar_Nome, '|', '|', '-', '-', '+', '+', '+', '+');
	wbkgd(Alterar_Nome,COLOR_PAIR(1));
	char Nome_Novo[30];

	do{
		mvwprintw(Alterar_Nome,3,30,"                                     ");
		wattron(Alterar_Nome,COLOR_PAIR(2));			
		mvwprintw(Alterar_Nome,1,10,"INSIRA O NOVO NOME DA EMISSORA OU INSIRA 0 PARA SAIR");
		wattroff(Alterar_Nome,COLOR_PAIR(2));

		wattron(Alterar_Nome,COLOR_PAIR(4));			
		mvwprintw(Alterar_Nome,3,30,"");
		wgetstr(Alterar_Nome,Nome_Novo);
		wattroff(Alterar_Nome,COLOR_PAIR(4));
		wattron(Alterar_Nome,COLOR_PAIR(3));
		if(strlen(Nome_Novo)>25)mvwprintw(Alterar_Nome,2,16,"O NOME DEVE CONTER MENOS DE 26 CARACTERES");
		if(Confirmar_Atualizacao(Nome_Novo)==1)mvwprintw(Alterar_Nome,2,15,"ESSE NOME DE EMISSORA JA ESTA INSERIDO");
		wattroff(Alterar_Nome,COLOR_PAIR(3));
		wattroff(Alterar_Nome,COLOR_PAIR(3));
		
	}while(strlen(Nome_Novo)>25 || Confirmar_Atualizacao(Nome_Novo)==1);

	mvwprintw(Alterar_Nome,1,1,"                                                             ");
	mvwprintw(Alterar_Nome,2,1,"                                                         ");

	Atualizar_Emissora(Nome, Nome_Novo);
	wattron(Alterar_Nome,COLOR_PAIR(2));	

	mvwprintw(Alterar_Nome,1,20,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Nome,3,15,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Nome,COLOR_PAIR(2));
	wgetch(Alterar_Nome);
	delwin(Alterar_Nome);
	Al_Emissora_Menu(Nome_Novo, Tipo);
}