
char Atualizar_Emissora(char Nome[30], char Nome_Novo[30]){

	MYSQL Conexao;
	Conexao=Conectar();
	char Alterar[1024];
	sprintf(Alterar, "UPDATE Emissoras SET Nome='%s' WHERE Nome='%s';", Nome_Novo, Nome);
	mysql_query(&Conexao, Alterar);
	mysql_close(&Conexao);
	
}


int Confirmar_Atualizacao(char Nome[30]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Emissoras where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}