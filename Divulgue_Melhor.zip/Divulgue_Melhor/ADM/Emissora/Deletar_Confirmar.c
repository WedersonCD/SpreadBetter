
WINDOW *Deletar_Confirmar;

int	O_Emissora();
char Del_Emissora();
char Deletar(char Nome[30]);
int Del_Confirmar(char Nome[30], char Tipo[7]){

	Deletar_Confirmar=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Deletar_Confirmar,COLOR_PAIR(1));
	char Alternativa;
	do{

				
		mvwprintw(Deletar_Confirmar,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Deletar_Confirmar,12,60,"DADOS DA EMISSORA");
		mvwprintw(Deletar_Confirmar,15,47,"+---------------------------+--------------------+");
		mvwprintw(Deletar_Confirmar,16,47,"|NOME DA EMISSORA           |TIPO DE SINAL       |");
		mvwprintw(Deletar_Confirmar,17,47,"+---------------------------+--------------------+");
		mvwprintw(Deletar_Confirmar,18,47,"|                           |                    |");
		mvwprintw(Deletar_Confirmar,19,47,"+---------------------------+--------------------+");
		mvwprintw(Deletar_Confirmar,35,0,"______________________________________________________________________________________________________________________________________________________");
				
		wattron(Deletar_Confirmar,COLOR_PAIR(4));
		mvwprintw(Deletar_Confirmar,18,48,"%s",Nome);
		mvwprintw(Deletar_Confirmar,18,76,"%s",Tipo);
		wattroff(Deletar_Confirmar,COLOR_PAIR(4));

		mvwprintw(Deletar_Confirmar,21,62,"CONFIRMAR EXCLUSAO");
		mvwprintw(Deletar_Confirmar,23,60,"1-Confirmar a exclusao.");
		mvwprintw(Deletar_Confirmar,25,58,"2-Retonar a tela anterior ");
		mvwprintw(Deletar_Confirmar,27,47,"0-Retronar ao menu de opçoes relacionadas a emissoras.");
		wattron(Deletar_Confirmar,COLOR_PAIR(2));
		mvwprintw(Deletar_Confirmar,29,51,"Pressione o numero correspondente a opção desejada");
		wattroff(Deletar_Confirmar,COLOR_PAIR(2));

		mvwprintw(Deletar_Confirmar,32,0,"");
		Alternativa=wgetch(Deletar_Confirmar);


		if(Alternativa=='1'){
			Deletar(Nome);
		}else if(Alternativa=='2'){
			Del_Emissora();
		}else if(Alternativa=='0'){
			delwin(Deletar_Confirmar);
			O_Emissora();
		}else{
			wattron(Deletar_Confirmar,COLOR_PAIR(3));
			mvwprintw(Deletar_Confirmar,20,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Deletar_Confirmar,COLOR_PAIR(3));

		}

	}while(Alternativa!='1' || Alternativa!='2'|| Alternativa!='3');
}

int Deletei(char Nome[30]){
	MYSQL Conexao;
	MYSQL_ROW Linhas;
	MYSQL_RES *Resp;
	Conexao=Conectar();
	char Selecionar[100];
	char Deletar[100];
	sprintf(Selecionar, "SELECT Emissora FROM Programa_De_TV WHERE  Emissora='%s';", Nome);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	if(Linhas=mysql_fetch_row(Resp)){
		mysql_close(&Conexao);
		return 1;
	}else{
		sprintf(Deletar, "DELETE FROM Emissoras WHERE Nome='%s';",Nome);
		mysql_query(&Conexao, Deletar);
		mysql_close(&Conexao);
		return 0;
	}

}

char Deletar(char Nome[30]){
	for(int x=20;x<33;x++)mvwprintw(Deletar_Confirmar,x,0,"                                                                                                                                       ");


	if(Deletei(Nome)==1){
		wattron(Deletar_Confirmar,COLOR_PAIR(2));	
		mvwprintw(Deletar_Confirmar,21,40,"ESSA EMISSORA NAO PODE SER EXCLUIDA POIS EXISTEM PROGRAMAS RELACIONADOS A ELA");
		mvwprintw(Deletar_Confirmar,23,50,"PRESSIONE QUALQUER TECLA PARA RETORNAR AO MENU");
		wattroff(Deletar_Confirmar,COLOR_PAIR(2));
		wgetch(Deletar_Confirmar);
		delwin(Deletar_Confirmar);
		O_Emissora();


	}else{
		wattron(Deletar_Confirmar,COLOR_PAIR(2));	
		mvwprintw(Deletar_Confirmar,21,60,"EXCLUSAO REALIZADA COM SUCESSO");
		mvwprintw(Deletar_Confirmar,23,55,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
		wattroff(Deletar_Confirmar,COLOR_PAIR(2));
		wgetch(Deletar_Confirmar);
		delwin(Deletar_Confirmar);
		O_Emissora();
	}
}

