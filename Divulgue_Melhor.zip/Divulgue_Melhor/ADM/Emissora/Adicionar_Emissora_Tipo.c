#include "Adicionar_Emissora_Confirmar.c"

WINDOW *Tipo_Emissora;

int T_Emissora(char Nome[40]){

	char Tipo;

	Tipo_Emissora=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Tipo_Emissora,COLOR_PAIR(1));

	do{

		
		mvwprintw(Tipo_Emissora,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Tipo_Emissora,12,60,"ADICIONAR NOVA EMISSORA");
		mvwprintw(Tipo_Emissora,15,50,"+---------------------------+--------------------+");
		mvwprintw(Tipo_Emissora,16,50,"|NOME DA EMISSORA           |TIPO DE SINAL       |");
		mvwprintw(Tipo_Emissora,17,50,"+---------------------------+--------------------+");
		mvwprintw(Tipo_Emissora,18,50,"|                           |                    |");
		mvwprintw(Tipo_Emissora,19,50,"+---------------------------+--------------------+");
		mvwprintw(Tipo_Emissora,35,0,"______________________________________________________________________________________________________________________________________________________");
		
		wattron(Tipo_Emissora,COLOR_PAIR(4));
		mvwprintw(Tipo_Emissora,18,51,"%s",Nome);
		wattroff(Tipo_Emissora,COLOR_PAIR(4));

		mvwprintw(Tipo_Emissora,21,68,"TIPO DE SINAL");
		wattron(Tipo_Emissora,COLOR_PAIR(2));
		mvwprintw(Tipo_Emissora,23,53,"1-Pressione 1 se a emissora for de sinal aberto");
		mvwprintw(Tipo_Emissora,25,51,"2-Pressione 2 se a emissora for de sinal fechado");
		mvwprintw(Tipo_Emissora,27,57,"3-Pressione 3 para reinserir o nome");
		mvwprintw(Tipo_Emissora,29,62,"4-Pressione 4 para cancelar");
		wattroff(Tipo_Emissora,COLOR_PAIR(2));

		mvwprintw(Tipo_Emissora,32,0,"");
		Tipo=wgetch(Tipo_Emissora);

		if(Tipo=='1'){
			Adicionar_Emissora_Confirmar(Nome,"Aberto");
			delwin(Tipo_Emissora);
		}else if(Tipo=='2'){
			Adicionar_Emissora_Confirmar(Nome,"Fechado");
			delwin(Tipo_Emissora);
		}else if(Tipo=='3'){
			A_Emissora();
			delwin(Tipo_Emissora);
		}else if(Tipo=='4'){
			O_Emissora();
			delwin(Tipo_Emissora);
		}else{
			wattron(Tipo_Emissora,COLOR_PAIR(3));
			mvwprintw(Tipo_Emissora,20,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Tipo_Emissora,COLOR_PAIR(3));

		}

	}while(Tipo!='1' || Tipo!='2'|| Tipo!='3' || Tipo!='4');

	wrefresh(Tipo_Emissora);
	delwin(Tipo_Emissora);
}
      
