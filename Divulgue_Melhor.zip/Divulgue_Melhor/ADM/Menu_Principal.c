#include "Emissora/Opcoes_Emissora.c"
#include "Programas/Opcoes_Programa.c"


WINDOW *Menu_Principal;


void Checa_Data();

int M_Principal(){

	Menu_Principal=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);


	wbkgd(Menu_Principal,COLOR_PAIR(1));
	char Tecla;
	do{
		Checa_Data();

		mvwprintw(Menu_Principal,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Menu_Principal,12,60,"MENU PRINCIPAL");
		mvwprintw(Menu_Principal,15,48,"1-Acessar opçoes relacionadas as emissoras");
		mvwprintw(Menu_Principal,17,44,"2-Acessar opçoes relacionadas a os programas de TV");

		wattron(Menu_Principal,COLOR_PAIR(2));
		mvwprintw(Menu_Principal,21,44,"Pressione o numero correspondente a opção desejada");
		wattroff(Menu_Principal,COLOR_PAIR(2));
		mvwprintw(Menu_Principal,23,0,"_______________________________________________________________________________________________________________________________________________________");

		Tecla=wgetch(Menu_Principal);
			if(Tecla=='1'){
				O_Emissora();
				break;
			}else if(Tecla=='2'){
				O_Programa();
			}else{
				wattron(Menu_Principal,COLOR_PAIR(3));
				mvwprintw(Menu_Principal,19,50, "POR FAVOR, PRESSIONE UM NUMERO VALIDO");
				wattroff(Menu_Principal,COLOR_PAIR(3));
			}
	}while(Tecla!='1' || Tecla!='2');

	wrefresh(Menu_Principal);
	delwin(Menu_Principal);

}

void Checa_Data(){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	char data1[10];
	char Query[190];
	sprintf(data1, "%s", Data());
	Conexao=Conectar();
	sprintf(Query,"SELECT Nome FROM Programa_De_TV WHERE H_Alteracao<='%s';",data1);
	mysql_query(&Conexao, Query);
	Resp=mysql_store_result(&Conexao);
	char Programas[1024]="";
	int Count=0;
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		sprintf(Programas, "%s, %s",Programas, Linhas[0]);
		Count++;
	}
	if(Count!=0){
		wattron(Menu_Principal,COLOR_PAIR(3));
		mvwprintw(Menu_Principal,11,5, "Os programas de TV:%s Precisam ser atualizados", Programas);
		wattroff(Menu_Principal,COLOR_PAIR(3));

	}
	mysql_close(&Conexao);

}