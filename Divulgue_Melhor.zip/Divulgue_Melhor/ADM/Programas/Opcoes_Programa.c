#include "Adicionar/Adicionar_Programa.c"
#include "Selecionar/Listar_Programa.c"
#include "Selecionar/Visualizar_Programa.c"
#include "Alterar/Alterar_Programa.c"
#include "Query_Programa.c"
#include "Excluir/Excluir_Programa.c"
#include "Data.c"

WINDOW *Opcoes_Programa;

int O_Programa(){

	Opcoes_Programa=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);


	wbkgd(Opcoes_Programa,COLOR_PAIR(1));
	char Tecla;
	int Aux=0;
while(1){
	mvwprintw(Opcoes_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
	mvwprintw(Opcoes_Programa,12,50,"Opcoes relacionadas a programas de TV");
	mvwprintw(Opcoes_Programa,14,44,"1-Visualizar lista de todos programas já inseridos");
	mvwprintw(Opcoes_Programa,16,53,"2-Adicionar novo programa");
	mvwprintw(Opcoes_Programa,18,48,"3-Alterar dados de programas já inseridos");
	mvwprintw(Opcoes_Programa,20,52,"4-Remover programa já inserido");
	mvwprintw(Opcoes_Programa,22,51,"5-Visualizar programa especifico");

	mvwprintw(Opcoes_Programa,24,53,"0-Retornar ao menu principal.");


	wattron(Opcoes_Programa,COLOR_PAIR(2));
	mvwprintw(Opcoes_Programa,26,44,"Pressione o numero correspondente a opção desejada");
	wattroff(Opcoes_Programa,COLOR_PAIR(2));
	mvwprintw(Opcoes_Programa,28,0,"______________________________________________________________________________________________________________________________________________________");

	Tecla=wgetch(Opcoes_Programa);
	if(Tecla=='1'){
		L_Programa(0, 0);
	}else if(Tecla=='0'){
		M_Principal();
	}else if(Tecla=='2'){
		A_Programa();
	}else if(Tecla=='3'){
		Al_Programa();
	}else if(Tecla=='4'){
		E_Programa();
	}else if(Tecla=='5'){
		V_Programa();
	}else{
			wattron(Opcoes_Programa,COLOR_PAIR(3));
			mvwprintw(Opcoes_Programa,25,50, "POR FAVOR, PRESSIONE UM NUMERO VALIDO");
			wattroff(Opcoes_Programa,COLOR_PAIR(3));
		}
}
	wrefresh(Opcoes_Programa);
	delwin(Opcoes_Programa);

}