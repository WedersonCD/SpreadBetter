WINDOW *Excluir_Programa;

void Certifica_Excluir(char Nome[]);
char Confirma_Exclusao(char ID[]);
void Deletar_Programa(char ID[]);

void Limpar_E(){
	for(int x=0;x<60;x++)
		for(int y=0;y<150;y++)
		mvwprintw(Excluir_Programa,x,y,"                                                                                                                                                         ");
}

void E_Programa(){
	Excluir_Programa=newwin(150,150,0,0);
	keypad(Excluir_Programa, TRUE);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Excluir_Programa,COLOR_PAIR(1));
	
	char ID[2]="";
	char Nome[26]="";
	char Emissora[26]="";
	char H_Inicial[8]="";
	char H_Final[8]="";
	char Ibope[3]="";
	char Tema[20]="";
	char String_Regioes[100]="";
	Certifica_Excluir(Nome);
	char Alternativa;


	do{
		Limpar_E();
		Retorna_Dados_Programa(ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, String_Regioes);
		wattron(Excluir_Programa,COLOR_PAIR(2));
		mvwprintw(Excluir_Programa,11,115,"Legenda:");
		mvwprintw(Excluir_Programa,12,130,"S-Sul");
		mvwprintw(Excluir_Programa,12,115,"N-Norte");
		mvwprintw(Excluir_Programa,13,130,"SD-Suldeste");
		mvwprintw(Excluir_Programa,13,115,"ND-Nordeste");
		mvwprintw(Excluir_Programa,14,115,"CO-Centro_Oeste");
		wattroff(Excluir_Programa,COLOR_PAIR(2));

		mvwprintw(Excluir_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Excluir_Programa,12,60,"ALTERAR PROGRAMA DE TV");
		mvwprintw(Excluir_Programa,15,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Excluir_Programa,16,5,"|Nome do programa           |Emissora                   |H_Inicial |H_Final |Ibope  |Tema Do Programa      |Regioes alcançadas       |");
		mvwprintw(Excluir_Programa,17,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Excluir_Programa,18,5,"|                           |                           |          |        |       |                      |                          |");
		mvwprintw(Excluir_Programa,19,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		
		wattron(Excluir_Programa,COLOR_PAIR(4));
		mvwprintw(Excluir_Programa,18,6,"%s",Nome);
		mvwprintw(Excluir_Programa,18,34,"%s",Emissora);
		mvwprintw(Excluir_Programa,18,62,"%s",H_Inicial);
		mvwprintw(Excluir_Programa,18,73,"%s",H_Final);
		mvwprintw(Excluir_Programa,18,82,"%s",Ibope);
		mvwprintw(Excluir_Programa,18,90,"%s",Tema);
		mvwprintw(Excluir_Programa,18,113,"%s",String_Regioes);
		wattroff(Excluir_Programa,COLOR_PAIR(4));

		mvwprintw(Excluir_Programa,21,60,"MENU EXCLUIR DADOS PROGRAMA");
		mvwprintw(Excluir_Programa,23,63,"1-Confirmar exclusão");
		mvwprintw(Excluir_Programa,24,60,"2-Selecionar outro programa");
		mvwprintw(Excluir_Programa,25,47,"0-Retronar ao menu de opções relacionadas a emissoras.");

		wattron(Excluir_Programa,COLOR_PAIR(2));
		mvwprintw(Excluir_Programa,27,51,"Pressione o numero correspondente a opção desejada");
		wattroff(Excluir_Programa,COLOR_PAIR(2));

		mvwprintw(Excluir_Programa,32,0,"");
		Alternativa=wgetch(Excluir_Programa);


		if(Alternativa=='1'){
			Confirma_Exclusao(ID);
			O_Programa();
		}else if(Alternativa=='2'){
			Certifica_Excluir(Nome);
		}else if(Alternativa=='0'){
			delwin(Excluir_Programa);
			O_Programa();
		}else{
			wattron(Excluir_Programa,COLOR_PAIR(3));
			mvwprintw(Excluir_Programa,26,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Excluir_Programa,COLOR_PAIR(3));

		}
	}while(Alternativa!='1' || Alternativa!='2');

	wrefresh(Excluir_Programa);
	delwin(Excluir_Programa);

}


char Confirma_Exclusao(char ID[]){

	Deletar_Programa(ID);
	Limpar_E();
	wattron(Excluir_Programa,COLOR_PAIR(2));	
	mvwprintw(Excluir_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Excluir_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Excluir_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Excluir_Programa,COLOR_PAIR(2));
	wgetch(Excluir_Programa);
	return '9';
}


void Certifica_Excluir(char Nome[]){
	for(int x=11;x<28;x++)mvwprintw(Excluir_Programa,x,0,"                                                                                                                                                      ");
	Limpar_E();
	int Aux=0;
    Criar_Tabela(Excluir_Programa, 17, "Programa_De_TV");

	while(Aux==0){
		mvwprintw(Excluir_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Excluir_Programa,12,65,"Excluir programa");
		wattron(Excluir_Programa,COLOR_PAIR(2));
		mvwprintw(Excluir_Programa,14,35,"Digite o nome do programa que desejas excluir ou digite 0 e aperte enter");
		wattroff(Excluir_Programa,COLOR_PAIR(2));

		mvwprintw(Excluir_Programa,15,70,"");
		wattron(Excluir_Programa,COLOR_PAIR(4));
		wgetstr(Excluir_Programa, Nome);
		wattroff(Excluir_Programa,COLOR_PAIR(4));

		if(Nome[0]=='0'){
			O_Programa();
		}else if(Checar_Nome(Nome)==0){
			wattron(Excluir_Programa,COLOR_PAIR(3));
			mvwprintw(Excluir_Programa,13,62, "PROGRAMA NAO ENCONTRADO");
			wattroff(Excluir_Programa,COLOR_PAIR(3));
		}else{
			Aux++;
		}
		mvwprintw(Excluir_Programa,15,70,"                                          ");

	}
	mvwprintw(Excluir_Programa,14,35,"                                                                                         ");
	mvwprintw(Excluir_Programa,13,10,"                                                                                                                                                                   ");

}