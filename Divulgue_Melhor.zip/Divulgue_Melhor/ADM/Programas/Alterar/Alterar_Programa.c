void Deletar_Regioes(char ID[]);
void Inserir_Regiao(struct regiao *Regiao, char ID[]);
void Preencher_Regiao(char ID[], struct regiao *Regiao);
void Retorna_Dados_Programa(char ID[], char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], char String_Regioes[]);
void Altera_Dados_Programa(char ID[], char Novo[], char Campo[]);
void Altera_Regiao_Programa(char ID, struct regiao *Regiao);
char Al_Emissora_Programa(char ID[], char Emissora[]);
char Al_Nome_Programa(char ID[], char Nome[]);
char Al_H_Inicial_Programa(char ID[], char H_Inicial[]);
char Al_H_Final_Programa(char ID[], char H_Final[]);
char Al_Ibope_Programa(char ID[], char Ibope[]);
char Al_Tema_Programa(char ID[], char Tema[]);
char Al_Regiao_Programa(char ID[], struct regiao *Regiao);
char Re_Regiao_Programa(char ID[], struct regiao *Regiao);
void Certifica(char Nome[]);
void Deletar_Regioes_P(char ID[], struct regiao *Regiao);

WINDOW *Alterar_Programa;

void Limpar(){
		for(int x=20;x<60;x++)
			for(int y=0;y<150;y++)
			mvwprintw(Alterar_Programa,x,y," ");

}

char Al_Programa(){

	Alterar_Programa=newwin(150,150,0,0);
	keypad(Alterar_Programa, TRUE);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Alterar_Programa,COLOR_PAIR(1));
	char ID[2]="";
	char Nome[26]="";
	char Emissora[26]="";
	char H_Inicial[8]="";
	char H_Final[8]="";
	char Ibope[3]="";
	char Tema[20]="";
	char String_Regioes[100]="";
	struct regiao Regiao;
	Certifica(Nome);
	char Alternativa;

	mvwprintw(Alterar_Programa,17,140,"              ");
	mvwprintw(Alterar_Programa,18,140,"              ");
	mvwprintw(Alterar_Programa,19,140,"              ");
	do{
		Limpar();
		Retorna_Dados_Programa(ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, String_Regioes);
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,11,115,"Legenda:");
		mvwprintw(Alterar_Programa,12,130,"S-Sul");
		mvwprintw(Alterar_Programa,12,115,"N-Norte");
		mvwprintw(Alterar_Programa,13,130,"SD-Sudeste");
		mvwprintw(Alterar_Programa,13,115,"ND-Nordeste");
		mvwprintw(Alterar_Programa,14,115,"CO-Centro_Oeste");
		wattroff(Alterar_Programa,COLOR_PAIR(2));

		mvwprintw(Alterar_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Alterar_Programa,12,60,"ALTERAR PROGRAMA DE TV");
		mvwprintw(Alterar_Programa,15,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Alterar_Programa,16,5,"|Nome do programa           |Emissora                   |H_Inicial |H_Final |Ibope  |Tema Do Programa      |Regioes alcançadas       |");
		mvwprintw(Alterar_Programa,17,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Alterar_Programa,18,5,"|                           |                           |          |        |       |                      |                          |");
		mvwprintw(Alterar_Programa,19,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		
		wattron(Alterar_Programa,COLOR_PAIR(4));
		mvwprintw(Alterar_Programa,18,6,"%s",Nome);
		mvwprintw(Alterar_Programa,18,34,"%s",Emissora);
		mvwprintw(Alterar_Programa,18,62,"%s",H_Inicial);
		mvwprintw(Alterar_Programa,18,73,"%s",H_Final);
		mvwprintw(Alterar_Programa,18,82,"%s",Ibope);
		mvwprintw(Alterar_Programa,18,90,"%s",Tema);
		mvwprintw(Alterar_Programa,18,113,"%s",String_Regioes);
		wattroff(Alterar_Programa,COLOR_PAIR(4));

		mvwprintw(Alterar_Programa,21,60,"MENU ALTERAR DADOS PROGRAMA");
		mvwprintw(Alterar_Programa,23,63,"1-Inserir outro nome.");
		mvwprintw(Alterar_Programa,24,66,"2-Mudar Emissora");
		mvwprintw(Alterar_Programa,25,63,"3-Mudar Horario Inicial.");
		mvwprintw(Alterar_Programa,26,65,"4-Mudar Horario Final.");
		mvwprintw(Alterar_Programa,27,67,"5-Mudar Ibope");
		mvwprintw(Alterar_Programa,28,68,"6-Mudar Tema");
		mvwprintw(Alterar_Programa,29,66,"7-Adicionar regioes");
		mvwprintw(Alterar_Programa,30,66,"8-Remover regioes");

		mvwprintw(Alterar_Programa,31,47,"0-Retronar ao menu de opções relacionadas a emissoras.");

		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,33,51,"Pressione o numero correspondente a opção desejada");
		wattroff(Alterar_Programa,COLOR_PAIR(2));

		mvwprintw(Alterar_Programa,32,0,"");
		Alternativa=wgetch(Alterar_Programa);


		if(Alternativa=='1'){
			Alternativa=Al_Nome_Programa(ID, Nome);
		}else if(Alternativa=='2'){
			Alternativa=Al_Emissora_Programa(ID, Emissora);
		}else if(Alternativa=='3'){
			Alternativa=Al_H_Inicial_Programa(ID, H_Inicial);
		}else if(Alternativa=='4'){
			Alternativa=Al_H_Final_Programa(ID, H_Final);
		}else if(Alternativa=='5'){
			Alternativa=Al_Ibope_Programa(ID, Ibope);
		}else if(Alternativa=='6'){
			Alternativa=Al_Tema_Programa(ID, Tema);
		}else if(Alternativa=='7'){
			Alternativa=Al_Regiao_Programa(ID, &Regiao);
		}else if(Alternativa=='8'){
			Alternativa=Re_Regiao_Programa(ID, &Regiao);
		}else if(Alternativa=='0'){
			delwin(Alterar_Programa);
			O_Programa();
		}else{
			wattron(Alterar_Programa,COLOR_PAIR(3));
			mvwprintw(Alterar_Programa,22,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Alterar_Programa,COLOR_PAIR(3));

		}
		if(Alternativa=='9'){
			wattron(Alterar_Programa,COLOR_PAIR(3));
			mvwprintw(Alterar_Programa,22,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Alterar_Programa,COLOR_PAIR(3));
		}

	}while(Alternativa!='1' || Alternativa!='2'|| Alternativa!='3' || Alternativa!='4' || Alternativa!='5'|| Alternativa!='6');
	wrefresh(Alterar_Programa);
	delwin(Alterar_Programa);

}

char Re_Regiao_Programa(char ID[], struct regiao *Regiao){
	Limpar();
	Preencher_Regiao(ID, Regiao);
	char Tecla, Auxc;
	int Aux=0;

	do{
		mvwprintw(Alterar_Programa,21,70,"Regioes");
		mvwprintw(Alterar_Programa,23,69,"1-Norte");
		mvwprintw(Alterar_Programa,24,68,"2-Nordeste");
		mvwprintw(Alterar_Programa,25,70,"3-Sul");
		mvwprintw(Alterar_Programa,26,68,"4-Sudeste");
		mvwprintw(Alterar_Programa,27,67,"5-Centro-Oeste");


		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,30,20,"Pressione o numero correspondente a região que não mais trasmite o programa ou pressione 0 para camcelar");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Alterar_Programa);

			if(Tecla=='0')return '9';
			if(Tecla=='1'){
				if(Regiao->Norte!=1){
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,28,54,"Essa região não trasmite o programa");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Norte=0;
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;

				}
			}else if(Tecla=='2'){
				if(Regiao->Nordeste!=1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,28,54,"Essa região não trasmite o programa");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                              ");

					Regiao->Nordeste=0;
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;
				}	

			}else if(Tecla=='3'){
				if(Regiao->Sul!=1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,28,54,"Essa região não trasmite o programa");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                              ");

					Regiao->Sul=0;
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;


				}	

			}else if(Tecla=='4'){
				if(Regiao->Suldeste!=1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,28,54,"Essa região não trasmite o programa");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                              ");

					Regiao->Suldeste=0;
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;
				}	

			}else if(Tecla=='5'){
				if(Regiao->Centro_Oeste!=1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");	
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,28,54,"Essa região não trasmite o programa");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                              ");

					Regiao->Centro_Oeste=0;
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;
				}	
			}else{
				wattron(Alterar_Programa,COLOR_PAIR(3));
				mvwprintw(Alterar_Programa,22,58,"                                       ");
				mvwprintw(Alterar_Programa,22,60,"Pressione uma opção valida");
				wattroff(Alterar_Programa,COLOR_PAIR(3));
			}

	}while(Aux==0);
	Deletar_Regioes_P(ID,Regiao);
	Limpar();
	wattron(Alterar_Programa,COLOR_PAIR(2));	
	mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Programa,COLOR_PAIR(2));
	wgetch(Alterar_Programa);
	return '9';

}

char Al_Regiao_Programa(char ID[], struct regiao *Regiao){

	Limpar();
	Preencher_Regiao(ID, Regiao);
	char Tecla, Auxc;
	int Aux=0;

	do{
		mvwprintw(Alterar_Programa,21,70,"Regioes");
		mvwprintw(Alterar_Programa,23,69,"1-Norte");
		mvwprintw(Alterar_Programa,24,68,"2-Nordeste");
		mvwprintw(Alterar_Programa,25,70,"3-Sul");
		mvwprintw(Alterar_Programa,26,68,"4-Sudeste");
		mvwprintw(Alterar_Programa,27,67,"5-Centro-Oeste");
		mvwprintw(Alterar_Programa,28,66,"6-Todas regioes");


		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,30,20,"Pressione o numero correspondente a região que a trasmissão do programa atinge ou pressione 0 para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Alterar_Programa);

			if(Tecla=='0')return '9';
			else if(Tecla=='1'){
				if(Regiao->Norte==1){
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,29,58,"Essa região já foi escolhida");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Norte=1;
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                                         ");

					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,30,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;

				}
			}else if(Tecla=='2'){
				if(Regiao->Nordeste==1){
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,29,58,"Essa região já foi escolhida");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Nordeste=1;
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,30,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;
				}	

			}else if(Tecla=='3'){
				if(Regiao->Sul==1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,29,58,"Essa região já foi escolhida");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Sul=1;
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                                         ");

					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,30,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;


				}	

			}else if(Tecla=='4'){
				if(Regiao->Suldeste==1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,29,58,"Essa região já foi escolhida");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Suldeste=1;
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                                         ");

					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,30,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;
				}	

			}else if(Tecla=='5'){
				if(Regiao->Centro_Oeste==1){
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");	
					wattron(Alterar_Programa,COLOR_PAIR(3));
					mvwprintw(Alterar_Programa,29,58,"Essa região já foi escolhida");
					wattroff(Alterar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Centro_Oeste=1;
					mvwprintw(Alterar_Programa,30,20,"                                                                                                                                                         ");

					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");
					wattron(Alterar_Programa,COLOR_PAIR(2));
					mvwprintw(Alterar_Programa,30,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Alterar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Alterar_Programa);
					mvwprintw(Alterar_Programa,29,20,"                                                                                                                                              ");

					if(Auxc=='1')Aux++;
				}	
			}else if(Tecla=='6'){
				Regiao->Norte=1;
				Regiao->Nordeste=1;
				Regiao->Sul=1;
				Regiao->Suldeste=1;
				Regiao->Centro_Oeste=1;
				Aux++;
			}else{
				wattron(Alterar_Programa,COLOR_PAIR(3));
				mvwprintw(Alterar_Programa,28,58,"                                       ");
				mvwprintw(Alterar_Programa,22,60,"Pressione uma opção valida");
				wattroff(Alterar_Programa,COLOR_PAIR(3));
			}

	}while(Aux==0);

	Limpar();

	Deletar_Regioes(ID);
	Inserir_Regiao(Regiao,ID);
	wattron(Alterar_Programa,COLOR_PAIR(2));	
	mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Programa,COLOR_PAIR(2));
	wgetch(Alterar_Programa);
	return '9';

	
}
char Al_Tema_Programa(char ID[], char Tema[]){
	Limpar();
	char N_Tema[30]="";

	do{
		mvwprintw(Alterar_Programa,24,57,"                                                                 ");
		mvwprintw(Alterar_Programa,21,72,"TEMA");
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,23,40,"Insira o tema do programa ou insira 0 e tecle ENTER para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,24,70,"");
		wattron(Alterar_Programa,COLOR_PAIR(4));
		wgetstr(Alterar_Programa,N_Tema);
		wattroff(Alterar_Programa,COLOR_PAIR(4));


		if(strlen(N_Tema)==1 && N_Tema[0]=='0'){
				return '9';
		}else if(strlen(N_Tema)>20){
				wattron(Alterar_Programa,COLOR_PAIR(3));
				mvwprintw(Alterar_Programa,22,52,"O NOME DO TEMA DEVE CONTER MENOS DE 21 LETRAS");
				wattroff(Alterar_Programa,COLOR_PAIR(3));
				mvwprintw(Alterar_Programa,28,70,"                                                                 ");
		}
	}while(strlen(N_Tema)>20);
	strcpy(Tema, N_Tema);

	mvwprintw(Alterar_Programa,23,10,"                                                                                                                                                                   ");
	mvwprintw(Alterar_Programa,22,10,"                                                                                                                                                                ");
	mvwprintw(Alterar_Programa,21,10,"                                                                                                                   ");	
	mvwprintw(Alterar_Programa,24,70,"                                           ");	
		
	mvwprintw(Alterar_Programa,21,1,"                                                             ");
	mvwprintw(Alterar_Programa,22,1,"                                                             ");
	Altera_Dados_Programa(ID, Tema, "Tema");
	wattron(Alterar_Programa,COLOR_PAIR(2));	
	mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Programa,COLOR_PAIR(2));
	wgetch(Alterar_Programa);


	return '9';


}


char Al_Ibope_Programa(char ID[], char Ibope[]){
	Limpar();

	char N_Ibope[3]="";
	mvwprintw(Alterar_Programa,24,57,"                                                                 ");
	mvwprintw(Alterar_Programa,21,71,"Ibope");
	wattron(Alterar_Programa,COLOR_PAIR(2));
	mvwprintw(Alterar_Programa,23,40,"Insira o Ibope do programa ou insira 0 e tecle ENTER para reinserir os dados");

	wattroff(Alterar_Programa,COLOR_PAIR(2));
	mvwprintw(Alterar_Programa,24,70,"");
	wattron(Alterar_Programa,COLOR_PAIR(4));
	wgetstr(Alterar_Programa,N_Ibope);
	wattroff(Alterar_Programa,COLOR_PAIR(4));
	if(strlen(Ibope)==1 && Ibope[0]=='0')return '9';
	strcpy(Ibope, N_Ibope);
	mvwprintw(Alterar_Programa,23,10,"                                                                                                                                                                   ");
	mvwprintw(Alterar_Programa,22,10,"                                                                                                                                                                ");
	mvwprintw(Alterar_Programa,21,10,"                                                                                                                   ");	
	mvwprintw(Alterar_Programa,24,70,"                                           ");	
		
	mvwprintw(Alterar_Programa,21,1,"                                                             ");
	mvwprintw(Alterar_Programa,22,1,"                                                             ");
	Altera_Dados_Programa(ID, Ibope, "Ibope");
	wattron(Alterar_Programa,COLOR_PAIR(2));	
	mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Programa,COLOR_PAIR(2));
	wgetch(Alterar_Programa);
	return '9';


}

char Al_H_Final_Programa(char ID[], char H_Final[]){

	Limpar();

	int Hora=0;
	int Minuto=0;
	int Tecla;

	do{
		mvwprintw(Alterar_Programa,21,60,"HORARIO INICIAL DO PROGRAMA");
		wattron(Alterar_Programa,COLOR_PAIR(3));
		mvwprintw(Alterar_Programa,23,70,"   ");
		mvwprintw(Alterar_Programa,23,71,"%i", Hora);
		wattroff(Alterar_Programa,COLOR_PAIR(3));
		mvwprintw(Alterar_Programa,23,73	,":%i", Minuto);
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,24,30,"Use as setas do teclado para regular a hora e tecle 1 para confirmar ou 0 para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Alterar_Programa);
					
		if(Tecla=='0')return '9';
		else if(Tecla==KEY_UP && Hora<24)Hora++;
		else if(Tecla==KEY_DOWN && Hora>0)Hora--;
	}while(Tecla!='1');
	Tecla=0;
	mvwprintw(Alterar_Programa,23,0,"                                                                                                                      ");
	do{
		mvwprintw(Alterar_Programa,23,74,"   ");
		mvwprintw(Alterar_Programa,23,71,"%i:",Hora);
		wattron(Alterar_Programa,COLOR_PAIR(3));
		mvwprintw(Alterar_Programa,23,74,"%i",Minuto);
		wattroff(Alterar_Programa,COLOR_PAIR(3));
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,24,30,"Use as setas do teclado para regular os minutos e tecle 1 para confirmar ou 0 para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Alterar_Programa);

		if(Tecla=='0')return '9';
		else if(Tecla==KEY_UP && Minuto<59)Minuto++;
		else if(Tecla==KEY_DOWN && Minuto>0)Minuto--;
	}while(Tecla!='1');

	sprintf(H_Final, "%i:%i", Hora, Minuto);
	mvwprintw(Alterar_Programa,23,10,"                                                                                                                                                                   ");
	mvwprintw(Alterar_Programa,22,10,"                                                                                                                                                                ");
	mvwprintw(Alterar_Programa,21,10,"                                                                                                                   ");	
	mvwprintw(Alterar_Programa,24,70,"                                           ");	
		
	mvwprintw(Alterar_Programa,21,1,"                                                             ");
	mvwprintw(Alterar_Programa,22,1,"                                                             ");
	Altera_Dados_Programa(ID, H_Final, "H_Final");
	wattron(Alterar_Programa,COLOR_PAIR(2));	
	mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Programa,COLOR_PAIR(2));
	wgetch(Alterar_Programa);
	return '9';
}

char Al_H_Inicial_Programa(char ID[], char H_Inicial[]){

	Limpar();
	int Hora=0;
	int Minuto=0;
	int Tecla;

	do{
		mvwprintw(Alterar_Programa,21,60,"HORARIO INICIAL DO PROGRAMA");
		wattron(Alterar_Programa,COLOR_PAIR(3));
		mvwprintw(Alterar_Programa,23,70,"   ");
		mvwprintw(Alterar_Programa,23,71,"%i", Hora);
		wattroff(Alterar_Programa,COLOR_PAIR(3));
		mvwprintw(Alterar_Programa,23,73	,":%i", Minuto);
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,24,30,"Use as setas do teclado para regular a hora e tecle 1 para confirmar ou 0 para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Alterar_Programa);
					
		if(Tecla=='0')return '9';
		else if(Tecla==KEY_UP && Hora<24)Hora++;
		else if(Tecla==KEY_DOWN && Hora>0)Hora--;
	}while(Tecla!='1');
	Tecla=0;
	mvwprintw(Alterar_Programa,23,0,"                                                                                                                      ");
	do{
		mvwprintw(Alterar_Programa,23,74,"   ");
		mvwprintw(Alterar_Programa,23,71,"%i:",Hora);
		wattron(Alterar_Programa,COLOR_PAIR(3));
		mvwprintw(Alterar_Programa,23,74,"%i",Minuto);
		wattroff(Alterar_Programa,COLOR_PAIR(3));
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,24,30,"Use as setas do teclado para regular os minutos e tecle 1 para confirmar ou 0 para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Alterar_Programa);

		if(Tecla=='0')return '9';
		else if(Tecla==KEY_UP && Minuto<59)Minuto++;
		else if(Tecla==KEY_DOWN && Minuto>0)Minuto--;
	}while(Tecla!='1');

	sprintf(H_Inicial, "%i:%i", Hora, Minuto);
	mvwprintw(Alterar_Programa,23,10,"                                                                                                                                                                   ");
	mvwprintw(Alterar_Programa,22,10,"                                                                                                                                                                ");
	mvwprintw(Alterar_Programa,21,10,"                                                                                                                   ");	
	mvwprintw(Alterar_Programa,24,70,"                                           ");	
		
	mvwprintw(Alterar_Programa,21,1,"                                                             ");
	mvwprintw(Alterar_Programa,22,1,"                                                             ");
	Altera_Dados_Programa(ID, H_Inicial, "H_Inicial");
	wattron(Alterar_Programa,COLOR_PAIR(2));	
	mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
	mvwprintw(Alterar_Programa,24,20,"                                                                                                                                                         ");

	mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
	wattroff(Alterar_Programa,COLOR_PAIR(2));
	wgetch(Alterar_Programa);
	return '9';

}

char Al_Emissora_Programa(char ID[], char Emissora[]){

	Limpar();	

	char Nova_Emissora[30]="";
	int Aux=0;
	do{
		mvwprintw(Alterar_Programa,24,57,"                                                                 ");
		mvwprintw(Alterar_Programa,21,50,"INSIRA O NOME DA EMISSORA DO PROGRAMA OU INSIRA 0 PARA SAIR");
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,23,30,"Insira a emissora que o programa esta relacionado ou insira 0 e tecle ENTER para reinserir os dados");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,24,70,"");
		wattron(Alterar_Programa,COLOR_PAIR(4));
		wgetstr(Alterar_Programa, Nova_Emissora);
		wattroff(Alterar_Programa,COLOR_PAIR(4));


		if(strlen(Nova_Emissora)==1 && Nova_Emissora[0]=='0')return '9';
		else if(Checar_Emissora(Nova_Emissora)==0){
			wattron(Alterar_Programa,COLOR_PAIR(3));
			mvwprintw(Alterar_Programa,22,64,"INSIRA UMA EMISSORA EXISTENTE");
			wattroff(Alterar_Programa,COLOR_PAIR(3));
			mvwprintw(Alterar_Programa,24,70,"                                                                 ");
		}else{
			Aux++;
		}

	}while(Aux==0);



		mvwprintw(Alterar_Programa,23,10,"                                                                                                                                                                   ");
		mvwprintw(Alterar_Programa,22,10,"                                                                                                                                                                ");
		mvwprintw(Alterar_Programa,21,10,"                                                                                                                   ");	
		mvwprintw(Alterar_Programa,24,70,"                                           ");	
		
		mvwprintw(Alterar_Programa,21,1,"                                                             ");
		mvwprintw(Alterar_Programa,22,1,"                                                             ");
		Altera_Dados_Programa(ID, Nova_Emissora, "Emissora");
		wattron(Alterar_Programa,COLOR_PAIR(2));	
		mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
		mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		wgetch(Alterar_Programa);
		strcpy(Emissora, Nova_Emissora);
		return '9';

}

char Al_Nome_Programa(char ID[], char Nome[]){
	Limpar();

	char Nome_Novo[30]="";
	int Aux=0;
	do{
		wattron(Alterar_Programa,COLOR_PAIR(2));			
		mvwprintw(Alterar_Programa,21,50,"INSIRA O NOVO NOME DO PROGRAMA OU INSIRA 0 PARA SAIR");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,23,70,"                                          ");

		wattron(Alterar_Programa,COLOR_PAIR(4));			
		mvwprintw(Alterar_Programa,23,70,"");
		wgetstr(Alterar_Programa,Nome_Novo);
		wattroff(Alterar_Programa,COLOR_PAIR(4));

		wattron(Alterar_Programa,COLOR_PAIR(3));
		if(strlen(Nome_Novo)>25){
			mvwprintw(Alterar_Programa,22,50,"O NOME DEVE CONTER MENOS DE 26 CARACTERES");
			Aux=0;
		}else if(Checar_Nome(Nome_Novo)==1){
			mvwprintw(Alterar_Programa,22,59,"ESSE NOME DE PROGRAMA JA ESTA INSERIDO");
			Aux=0;
		}else if(Nome_Novo[0]=='0' && strlen(Nome_Novo)==1){
			return '9';
		}else{
			Aux=1;
		}
		wattroff(Alterar_Programa,COLOR_PAIR(3));
		
	}while(Aux==0);

		mvwprintw(Alterar_Programa,23,10,"                                                                                                                                                                   ");
		mvwprintw(Alterar_Programa,22,10,"                                                                                                                                                                ");
		mvwprintw(Alterar_Programa,21,10,"                                                                                                                   ");	
		
		mvwprintw(Alterar_Programa,21,1,"                                                             ");
		mvwprintw(Alterar_Programa,22,1,"                                                             ");
		Altera_Dados_Programa(ID, Nome_Novo, "Nome");
		wattron(Alterar_Programa,COLOR_PAIR(2));	
		mvwprintw(Alterar_Programa,21,55,"ALTERACAO REALIZADA COM SUCESSO");
		mvwprintw(Alterar_Programa,23,51,"PRESSIONE QUALQUER TECLA PARA CONTINUAR");
		wattroff(Alterar_Programa,COLOR_PAIR(2));
		wgetch(Alterar_Programa);
		strcpy(Nome, Nome_Novo);
		return '9';	
}




void Certifica(char Nome[]){
    Criar_Tabela(Alterar_Programa, 17, "Programa_De_TV");
	int Aux=0;
	
	while(Aux==0){
		mvwprintw(Alterar_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Alterar_Programa,12,60,"ALTERAR DADOS PROGRAMA");
		wattron(Alterar_Programa,COLOR_PAIR(2));
		mvwprintw(Alterar_Programa,14,35,"Digite o nome do programa cujos dados desejas alterar ou digite 0 e aperte enter");
		wattroff(Alterar_Programa,COLOR_PAIR(2));

		mvwprintw(Alterar_Programa,15,70,"");
		wattron(Alterar_Programa,COLOR_PAIR(4));
		wgetstr(Alterar_Programa, Nome);
		wattroff(Alterar_Programa,COLOR_PAIR(4));

		if(Nome[0]=='0'){
			O_Programa();
		}else if(Checar_Nome(Nome)==0){
			wattron(Alterar_Programa,COLOR_PAIR(3));
			mvwprintw(Alterar_Programa,13,60, "PROGRAMA NAO ENCONTRADO");
			wattroff(Alterar_Programa,COLOR_PAIR(3));
		}else{
			Aux++;
		}
		mvwprintw(Alterar_Programa,15,70,"                                          ");

	}
		mvwprintw(Alterar_Programa,14,35,"                                                                                         ");
	mvwprintw(Alterar_Programa,13,10,"                                                                                                                                                                   ");

}