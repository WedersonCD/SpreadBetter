int Checar_Nome(char Nome[30]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Programa_De_TV where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}

int Checar_Emissora(char Emissora[]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Emissoras where Nome='%s';", Emissora);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}