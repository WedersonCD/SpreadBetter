char *data(void);

void Deletar_Programa(char ID[]){
	
	Deletar_Regioes(ID);
	MYSQL Conexao;
	Conexao=Conectar();
	char Deletar[1000]="";
	sprintf(Deletar, "DELETE FROM Programa_De_TV where ID=%s;", ID);
	mysql_query(&Conexao, Deletar);
	mysql_close(&Conexao);

}

char *Format(int number){      
   char    *retorno,
      ret[100];
   int    i;

   if (number < 10){
      sprintf(ret,"0%d",number);
      retorno = ret;
      return retorno;
   }
   else{
      sprintf(ret,"%d",number);
      retorno = ret;
      return retorno;
   }
}      

char *Data(void){

   int dia,mes,ano;
   char   var1[100],
      var2[100],
      var3[100],
      var4[100],
      *dataPtr;
   struct tm *local;
   time_t t;

   t = time(NULL);
   local = localtime(&t);

   dia = local -> tm_mday;
   mes = local -> tm_mon +1;
   ano = local -> tm_year + 1900;
   if(dia>15){
   	dia = local -> tm_mday-15;
   }else{
   dia = local -> tm_mday+15;
   mes = local -> tm_mon;

   }
   sprintf(var1,"%s",Format(dia));
   sprintf(var2,"%s",Format(mes));
   sprintf(var3,"%s",Format(ano));

   sprintf(var4,"%s-%s-%s",var3,var2,var1);

   dataPtr = var4;
   return dataPtr;

}


void Deletar_Regioes_P(char ID[], struct regiao *Regiao){

	char Deletar[1000]="";
	MYSQL Conexao;
	Conexao=Conectar();

	if(Regiao->Norte==0){
		sprintf(Deletar, "DELETE FROM Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao=1;", ID);
		mysql_query(&Conexao, Deletar);
	}
	if(Regiao->Sul==0){
		sprintf(Deletar, "DELETE FROM Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao=2;", ID);
		mysql_query(&Conexao, Deletar);
	}
	if(Regiao->Suldeste==0){
		sprintf(Deletar, "DELETE FROM Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao= );", ID);
		mysql_query(&Conexao, Deletar);
	}
	if(Regiao->Nordeste==0){
		sprintf(Deletar, "DELETE FROM Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao=3;", ID);
		mysql_query(&Conexao, Deletar);

	}
	if(Regiao->Centro_Oeste==0){
		sprintf(Deletar, "DELETE FROM Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao=5;", ID);
		mysql_query(&Conexao, Deletar);
	}

	mysql_close(&Conexao);
}

void Deletar_Regioes(char ID[]){
	MYSQL Conexao;
	Conexao=Conectar();
	char Deletar[1024]="";
	sprintf(Deletar, "DELETE FROM Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s",ID);
	mysql_query(&Conexao, Deletar); 
	mysql_close(&Conexao);
}



void Inserir_Regiao(struct regiao *Regiao, char ID[]){

	char Inserir_R[1000]="";
	MYSQL Conexao;
	Conexao=Conectar();

	if(Regiao->Norte==1){
		sprintf(Inserir_R, "INSERT INTO Programa_Regiao(ID_Programa, ID_Regiao) values(%s, 1);", ID);
		mysql_query(&Conexao, Inserir_R);
	}
	if(Regiao->Sul==1){
		sprintf(Inserir_R, "INSERT INTO Programa_Regiao(ID_Programa, ID_Regiao) values(%s, 2);", ID);
		mysql_query(&Conexao, Inserir_R);
	}
	if(Regiao->Suldeste==1){
		sprintf(Inserir_R, "INSERT INTO Programa_Regiao(ID_Programa, ID_Regiao) values(%s , 4);", ID);
		mysql_query(&Conexao, Inserir_R);
	}
	if(Regiao->Nordeste==1){
		sprintf(Inserir_R, "INSERT INTO Programa_Regiao(ID_Programa, ID_Regiao) values(%s, 3);", ID);
		mysql_query(&Conexao, Inserir_R);

	}
	if(Regiao->Centro_Oeste==1){
		sprintf(Inserir_R, "INSERT INTO Programa_Regiao(ID_Programa, ID_Regiao) values(%s, 5);", ID);
		mysql_query(&Conexao, Inserir_R);
	}

	mysql_close(&Conexao);
}

//void Alterar_Regioes(char ID[], struct regiao **Regiao){

//}

void Preencher_Regiao(char ID[], struct regiao *Regiao){
	//0-Norte 1-Sul 2-Nordeste 3-Suldeste 4-Centro-Oeste

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;

	Conexao=Conectar();
	char Query[1024];
	sprintf(Query,"select distinct Programa_Regiao.ID_Regiao from Programa_Regiao, Programa_De_TV where Programa_Regiao.ID_Programa=%s ORDER BY ID_Regiao DESC;", ID);
	mysql_query(&Conexao, Query);
	Resp=mysql_store_result(&Conexao);
	int Y;
    while((Linhas=mysql_fetch_row(Resp))!=NULL){


			if(strcmp(Linhas[0],"1")==0)Regiao->Norte=1;

			if(strcmp(Linhas[0],"2")==0)Regiao->Sul=1;

			if(strcmp(Linhas[0],"3")==0)Regiao->Nordeste=1;

			if(strcmp(Linhas[0],"4")==0)Regiao->Suldeste=1;

			if(strcmp(Linhas[0],"5")==0)Regiao->Centro_Oeste=1;

	}
	mysql_close(&Conexao);

}


void Altera_Dados_Programa(char ID[], char Novo[], char Campo[]){
	char data1[10];
	sprintf(data1, "%s", data());

	MYSQL Conexao;
	Conexao=Conectar();
	char Alterar[1024];
	if(strcmp(Campo,"Ibope")==0)
	sprintf(Alterar, "UPDATE Programa_De_TV SET %s='%s', H_Alteracao='%s' WHERE ID='%s'; ",Campo, Novo, data1, ID);
	else
	sprintf(Alterar, "UPDATE Programa_De_TV SET %s='%s' WHERE ID='%s'; ",Campo, Novo, ID);

	mysql_query(&Conexao, Alterar);
	mysql_close(&Conexao);


}

void Retorna_Dados_Programa(char ID[], char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], char String_Regioes[]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	
	Conexao=Conectar();

	char Selecionar[1024];

	sprintf(Selecionar,	"SELECT ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema  FROM Programa_De_TV where Nome='%s';", Nome);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
    while((Linhas=mysql_fetch_row(Resp))!=NULL){
    	strcpy(ID, Linhas[0]);
    	Listar_Regiao(Linhas[0], String_Regioes);
		strcpy(Nome,Linhas[1]);
		strcpy(Emissora,Linhas[2]);
		strcpy(H_Inicial,Linhas[3]);
		strcpy(H_Final,Linhas[4]);
		strcpy(Ibope,Linhas[5]);
		strcpy(Tema,Linhas[6]);
	}
	mysql_close(&Conexao);

}

int Checar_Data(char Nome[]){

	MYSQL Conexao;
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	char data1[10];
	char Query[190];
	sprintf(data1, "%s", Data());
	Conexao=Conectar();
	sprintf(Query,"SELECT Nome FROM Programa_De_TV WHERE H_Alteracao<='%s' AND Nome='%s';",data1, Nome);
	mysql_query(&Conexao, Query);
	Resp=mysql_store_result(&Conexao);

	if((Linhas=mysql_fetch_row(Resp))!=NULL){
		mysql_close(&Conexao);
		return 0;
	}else{
		mysql_close(&Conexao);
		return 1;
	}

}

void Listar_Regiao(char ID[], char Regiao[]){

	MYSQL Conexao;
	Conexao=Conectar();
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;
	char Selecionar[1024];
	sprintf(Selecionar, "SELECT Regiao.Nome FROM Regiao, Programa_Regiao WHERE Programa_Regiao.ID_Programa=%s and Programa_Regiao.ID_Regiao=Regiao.ID;", ID);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	strcpy(Regiao,"");
	while((Linhas=mysql_fetch_row(Resp))!=NULL){
		sprintf(Regiao,"%s %s ",Regiao, Linhas[0]);
	}

	mysql_close(&Conexao);

}


int Inserir_Programa(char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], struct regiao *Regiao){
	
	char Inserir[1024]="";
	char Data[15]="";
	char Selecionar[1024]="";

	sprintf(Data, "%s", data());
	
	MYSQL Conexao;
	Conexao=Conectar();
	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;

	sprintf(Inserir, "INSERT INTO Programa_De_TV(Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, H_Alteracao) values('%s', '%s', '%s', '%s', '%s', '%s', '%s');", Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, Data);
	mysql_query(&Conexao, Inserir);
	sprintf(Selecionar, "SELECT ID FROM Programa_De_TV where Nome='%s';", Nome);
	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	Linhas=mysql_fetch_row(Resp);

	Inserir_Regiao(Regiao, Linhas[0]);

	mysql_close(&Conexao);
}


int Checar_Nome(char Nome[30]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Programa_De_TV where Nome='%s';", Nome);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}

int Checar_Emissora(char Emissora[]){

	MYSQL Conexao;
	Conexao=Conectar();

	MYSQL_RES *Resp;
	MYSQL_ROW Linhas;


	char Selecionar[1024];
	sprintf(Selecionar,"SELECT * FROM Emissoras where Nome='%s';", Emissora);

	mysql_query(&Conexao, Selecionar);
	Resp=mysql_store_result(&Conexao);
	
	if(mysql_fetch_row(Resp)==0){
		mysql_close(&Conexao);
		return 0;
	}
	else{ 
		mysql_close(&Conexao);
		return 1;
	}

}