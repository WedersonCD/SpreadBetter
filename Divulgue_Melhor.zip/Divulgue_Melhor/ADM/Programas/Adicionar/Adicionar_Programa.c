struct regiao{

	int Norte;
	int Nordeste;
	int Sul;
	int Suldeste;
	int Centro_Oeste;
};


WINDOW *Adicionar_Programa;

int O_Programa();
int Checar_Nome(char Nome[]);
int Checar_Emissora(char Emissora[]);
void A_Nome(char Nome[]);
int Relacionar_Regioes(struct regiao *Regiao);
void Relacionar_Emissora(char Emissora[]);
void Relacionar_H_Inicial(char H_Inicial[]);
void Relacionar_H_Final(char H_Final[]);
void Relacionar_Ibope(char Ibope[]);
void Relacionar_Tema(char Tema[]);
void Regioes_String(char String_Regioes[], struct regiao *Regiao );
void C_Insercao();
int Inserir_Programa(char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], struct regiao *Regiao);

int A_Programa(){
	Adicionar_Programa=newwin(150,150,0,0);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Adicionar_Programa,COLOR_PAIR(1));
	keypad(Adicionar_Programa, TRUE);

	char Nome[26]="";
	char Emissora[26]="";
	char H_Inicial[8]="";
	char H_Final[8]="";
	char Ibope[3]="";
	char Tema[20]="";
	char String_Regioes[100]="";
	int Aux=0;
	struct regiao Regiao;
	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                    ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	



	
	mvwprintw(Adicionar_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
	mvwprintw(Adicionar_Programa,12,60,"ADICIONAR NOVO PROGRAMA DE TV");
	mvwprintw(Adicionar_Programa,15,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
	mvwprintw(Adicionar_Programa,16,5,"|Nome do programa           |Emissora                   |H_Inicial |H_Final |Ibope  |Tema Do Programa      |Regioes alcançadas       |");
	mvwprintw(Adicionar_Programa,17,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
	mvwprintw(Adicionar_Programa,18,5,"|                           |                           |          |        |       |                      |                          |");
	mvwprintw(Adicionar_Programa,19,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");

	A_Nome(Nome);
	mvwprintw(Adicionar_Programa,18,6,"%s",Nome);

	
	Relacionar_Emissora(Emissora);
	mvwprintw(Adicionar_Programa,18,34,"%s",Emissora);

	Relacionar_H_Inicial(H_Inicial);
	mvwprintw(Adicionar_Programa,18,62,"%s",H_Inicial);

	Relacionar_H_Final(H_Final);
	mvwprintw(Adicionar_Programa,18,73,"%s",H_Final);

	Relacionar_Ibope(Ibope);
	mvwprintw(Adicionar_Programa,18,82,"%s",Ibope);

	Relacionar_Tema(Tema);
	mvwprintw(Adicionar_Programa,18,90,"%s",Tema);

	Relacionar_Regioes(&Regiao);
	Regioes_String(String_Regioes, &Regiao);
	mvwprintw(Adicionar_Programa,18,113,"%s",String_Regioes);
	
	wattron(Adicionar_Programa,COLOR_PAIR(2));
	mvwprintw(Adicionar_Programa,11,112,"Legenda:");
	mvwprintw(Adicionar_Programa,12,112,"S-Sul");
	mvwprintw(Adicionar_Programa,12,124,"N-Norte");
	mvwprintw(Adicionar_Programa,13,112,"SD-Sudeste");
	mvwprintw(Adicionar_Programa,13,124,"ND-Nordeste");
	mvwprintw(Adicionar_Programa,14,112,"CO-Centro_Oeste");
	wattroff(Adicionar_Programa,COLOR_PAIR(2));

	C_Insercao();
    Inserir_Programa(Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, &Regiao);
    O_Programa();
	wrefresh(Adicionar_Programa);
	delwin(Adicionar_Programa);
}

void C_Insercao(){
	char Tecla;
	int Aux=0;


do{
	mvwprintw(Adicionar_Programa,21,70,"CONFIRMAR INSERCAO");
	wattron(Adicionar_Programa,COLOR_PAIR(2));
	mvwprintw(Adicionar_Programa,23,50,"Pressione 1 para confirmar ou 0 para reinserir os dados");
	wattroff(Adicionar_Programa,COLOR_PAIR(2));
	
	Tecla=wgetch(Adicionar_Programa);
	if(Tecla=='1'){
		mvwprintw(Adicionar_Programa,22,40,"                                                                         ");
		mvwprintw(Adicionar_Programa,23,40,"                                                                         ");
		
		mvwprintw(Adicionar_Programa,21,64,"PROGRAMA CADASTRADO COM SUCESSO!");
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,23,55,"Pressione qualquer tecla para retornar ao menu!");
		wattroff(Adicionar_Programa,COLOR_PAIR(2));

		wgetch(Adicionar_Programa);
		Aux=1;
	}else if(Tecla=='0')A_Programa();
	else{
		wattron(Adicionar_Programa,COLOR_PAIR(3));
		mvwprintw(Adicionar_Programa,22,67,"Pressione uma opção valida");
		wattroff(Adicionar_Programa,COLOR_PAIR(3));
	}
}while(Aux==0);

}

void Regioes_String(char String_Regioes[], struct regiao *Regiao ){

	if(Regiao->Norte==1)sprintf(String_Regioes, "%s  N", String_Regioes);
	if(Regiao->Sul==1)sprintf(String_Regioes, "%s  S", String_Regioes);
	if(Regiao->Suldeste==1)sprintf(String_Regioes, "%s  SD", String_Regioes);
	if(Regiao->Nordeste==1)sprintf(String_Regioes, "%s ND", String_Regioes);
	if(Regiao->Centro_Oeste==1)sprintf(String_Regioes, "%s CO", String_Regioes);
}


int Relacionar_Regioes(struct regiao *Regiao){

	char Tecla, Auxc;
	int Aux=0;

	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	
	do{
		mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");


		mvwprintw(Adicionar_Programa,21,70,"Regioes");
		mvwprintw(Adicionar_Programa,23,69,"1-Norte");
		mvwprintw(Adicionar_Programa,24,68,"2-Nordeste");
		mvwprintw(Adicionar_Programa,25,70,"3-Sul");
		mvwprintw(Adicionar_Programa,26,68,"4-Sudeste");
		mvwprintw(Adicionar_Programa,27,67,"5-Centro-Oeste");
		mvwprintw(Adicionar_Programa,28,66,"6-Todas regioes");


		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,29,20,"Pressione o numero correspondente a região que a trasmissão do programa atinge ou pressione 0 para reinserir os dados");
		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Adicionar_Programa);

			if(Tecla=='0')A_Programa();
			else if(Tecla=='1'){
				if(Regiao->Norte==1){
					wattron(Adicionar_Programa,COLOR_PAIR(3));
					mvwprintw(Adicionar_Programa,22,58,"Essa região já foi escolhida");
					wattroff(Adicionar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Norte=1;
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(2));
					mvwprintw(Adicionar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Adicionar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Adicionar_Programa);
					if(Auxc=='1')Aux++;

				}
			}else if(Tecla=='2'){
				if(Regiao->Nordeste==1){
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(3));
					mvwprintw(Adicionar_Programa,22,58,"Essa região já foi escolhida");
					wattroff(Adicionar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Nordeste=1;
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(2));
					mvwprintw(Adicionar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Adicionar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Adicionar_Programa);
					if(Auxc=='1')Aux++;
				}	
			}else if(Tecla=='3'){

				if(Regiao->Sul==1){
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(3));
					mvwprintw(Adicionar_Programa,22,58,"Essa região já foi escolhida");
					wattroff(Adicionar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Sul=1;
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(2));
					mvwprintw(Adicionar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Adicionar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Adicionar_Programa);
					if(Auxc=='1')Aux++;


				}	
			}else if(Tecla=='4'){
				if(Regiao->Suldeste==1){
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(3));
					mvwprintw(Adicionar_Programa,22,58,"Essa região já foi escolhida");
					wattroff(Adicionar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Suldeste=1;
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(2));
					mvwprintw(Adicionar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Adicionar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Adicionar_Programa);
					if(Auxc=='1')Aux++;


				}	
			}else if(Tecla=='5'){
				if(Regiao->Centro_Oeste==1){
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");	
					wattron(Adicionar_Programa,COLOR_PAIR(3));
					mvwprintw(Adicionar_Programa,22,58,"Essa região já foi escolhida");
					wattroff(Adicionar_Programa,COLOR_PAIR(3));
				}else{
					Regiao->Centro_Oeste=1;
					mvwprintw(Adicionar_Programa,29,20,"                                                                                                                                              ");
					wattron(Adicionar_Programa,COLOR_PAIR(2));
					mvwprintw(Adicionar_Programa,29,40,"Pressione 1 para concluir a operação ou 0 para selecionar outra região ");
					wattroff(Adicionar_Programa,COLOR_PAIR(2));
					Auxc=wgetch(Adicionar_Programa);
					if(Auxc=='1')Aux++;
				}	
			}else if(Tecla=='6'){
				Regiao->Norte=1;
				Regiao->Nordeste=1;
				Regiao->Sul=1;
				Regiao->Suldeste=1;
				Regiao->Centro_Oeste=1;
				Aux++;
			}else{
				wattron(Adicionar_Programa,COLOR_PAIR(3));
				mvwprintw(Adicionar_Programa,28,58,"                                       ");
				mvwprintw(Adicionar_Programa,22,58,"Pressione uma opção valida");
				wattroff(Adicionar_Programa,COLOR_PAIR(3));
			}

	}while(Aux==0);
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                                                                    ");
	mvwprintw(Adicionar_Programa,22,0,"        	                                                                                                                                                           ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                   ");	
	mvwprintw(Adicionar_Programa,25,0,"        	                                                                                                                                                           ");
	mvwprintw(Adicionar_Programa,26,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,27,0,"                                                                                                                                                          ");	
	mvwprintw(Adicionar_Programa,28,0,"                                                                                                                                                          ");	
	mvwprintw(Adicionar_Programa,29,0,"                                                                                                                                                          ");	
	mvwprintw(Adicionar_Programa,30,0,"                                                                                                                                                          ");	


}






void Relacionar_Tema(char Tema[]){

	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	

	char Aux[3];
	do{
		mvwprintw(Adicionar_Programa,24,57,"                                                                 ");
		mvwprintw(Adicionar_Programa,21,72,"TEMA");
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,23,40,"Insira o tema do programa ou insira 0 e tecle ENTER para reinserir os dados");
		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,24,70,"");
		wattron(Adicionar_Programa,COLOR_PAIR(4));
		wgetstr(Adicionar_Programa,Tema);
		wattroff(Adicionar_Programa,COLOR_PAIR(4));


		if(strlen(Tema)==1 && Tema[0]=='0'){
				A_Programa();
		}else if(strlen(Tema)>20){
				wattron(Adicionar_Programa,COLOR_PAIR(3));
				mvwprintw(Adicionar_Programa,22,52,"O NOME DO TEMA DEVE CONTER MENOS DE 21 LETRAS");
				wattroff(Adicionar_Programa,COLOR_PAIR(3));
				mvwprintw(Adicionar_Programa,28,70,"                                                                 ");
		}
	}while(strlen(Tema)>20);

}


void Relacionar_Ibope(char Ibope[]){

	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	

	char Aux[3];
	mvwprintw(Adicionar_Programa,24,57,"                                                                 ");
	mvwprintw(Adicionar_Programa,21,71,"Ibope");
	wattron(Adicionar_Programa,COLOR_PAIR(2));
	mvwprintw(Adicionar_Programa,23,40,"Insira o Ibope do programa ou insira 0 e tecle ENTER para reinserir os dados");

	wattroff(Adicionar_Programa,COLOR_PAIR(2));
	mvwprintw(Adicionar_Programa,24,70,"");
	wattron(Adicionar_Programa,COLOR_PAIR(4));
	wgetstr(Adicionar_Programa,Ibope);
	wattroff(Adicionar_Programa,COLOR_PAIR(4));


	if(strlen(Ibope)==1 && Ibope[0]=='0')A_Programa();

}




void Relacionar_H_Inicial(char H_Inicial[]){
	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                    ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	
	int Hora=0;
	int Minuto=0;
	int Tecla;

	do{
		mvwprintw(Adicionar_Programa,21,60,"HORARIO INICIAL DO PROGRAMA");
		wattron(Adicionar_Programa,COLOR_PAIR(3));
		mvwprintw(Adicionar_Programa,23,70,"   ");
		mvwprintw(Adicionar_Programa,23,71,"%i", Hora);
		wattroff(Adicionar_Programa,COLOR_PAIR(3));
		mvwprintw(Adicionar_Programa,23,73	,":%i", Minuto);
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,24,30,"Use as setas do teclado para regular a hora e tecle 1 para confirmar ou 0 para reinserir os dados");
		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Adicionar_Programa);
					
		if(Tecla=='0')A_Programa();
		else if(Tecla==KEY_UP && Hora<24)Hora++;
		else if(Tecla==KEY_DOWN && Hora>0)Hora--;
	}while(Tecla!='1');
	Tecla=0;
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                      ");
	do{
		mvwprintw(Adicionar_Programa,23,74,"   ");
		mvwprintw(Adicionar_Programa,23,71,"%i:",Hora);
		wattron(Adicionar_Programa,COLOR_PAIR(3));
		mvwprintw(Adicionar_Programa,23,74,"%i",Minuto);
		wattroff(Adicionar_Programa,COLOR_PAIR(3));
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,24,30,"Use as setas do teclado para regular os minutos e tecle 1 para confirmar ou 0 para reinserir os dados");
		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Adicionar_Programa);

		if(Tecla=='0')A_Programa();
		else if(Tecla==KEY_UP && Minuto<59)Minuto++;
		else if(Tecla==KEY_DOWN && Minuto>0)Minuto--;
	}while(Tecla!='1');

	sprintf(H_Inicial, "%i:%i", Hora, Minuto);
}


void Relacionar_H_Final(char H_Final[]){
	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                    ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	

	int Hora=0;
	int Minuto=0;
	int Tecla;
	
	do{
		mvwprintw(Adicionar_Programa,21,55,"HORARIO DO TERMINIO DO PROGRAMA");
		wattron(Adicionar_Programa,COLOR_PAIR(3));
		mvwprintw(Adicionar_Programa,23,70,"   ");
		mvwprintw(Adicionar_Programa,23,71,"%i", Hora);
		wattroff(Adicionar_Programa,COLOR_PAIR(3));
		mvwprintw(Adicionar_Programa,23,73	,":%i", Minuto);
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,24,30,"Use as setas do teclado para regular a hora e tecle 1 para confirmar ou tecle 0 para reinserir os dados");
		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		Tecla=wgetch(Adicionar_Programa);
		if(Tecla=='0')A_Programa();
		else if(Tecla==KEY_UP && Hora<24)Hora++;
		else if(Tecla==KEY_DOWN && Hora>0)Hora--;
	}while(Tecla!='1');
		Tecla=0;
		mvwprintw(Adicionar_Programa,23,0,"                                                                                                                      ");
		do{
			mvwprintw(Adicionar_Programa,23,74,"   ");

			mvwprintw(Adicionar_Programa,23,71,"%i:",Hora);
			wattron(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,23,74,"%i",Minuto);
			wattroff(Adicionar_Programa,COLOR_PAIR(3));
			wattron(Adicionar_Programa,COLOR_PAIR(2));
			mvwprintw(Adicionar_Programa,24,30,"Use as setas do teclado para regular os minutos e tecle 1 para confirmar ou tecle 0 para reinserir os dados");
			wattroff(Adicionar_Programa,COLOR_PAIR(2));
			Tecla=wgetch(Adicionar_Programa);
			if(Tecla=='0')A_Programa();
			else if(Tecla==KEY_UP && Minuto<59)Minuto++;
			else if(Tecla==KEY_DOWN && Minuto>0)Minuto--;
		}while(Tecla!='1');

			sprintf(H_Final, "%i:%i", Hora, Minuto);
}

void Relacionar_Emissora(char Emissora[]){
	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	

	int Aux=0;
	do{
		mvwprintw(Adicionar_Programa,24,57,"                                                                 ");

		mvwprintw(Adicionar_Programa,21,71,"EMISSORA");
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,23,30,"Insira a emissora que o programa esta relacionado ou insira 0 e tecle ENTER para reinserir os dados");

		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,24,70,"");
		wattron(Adicionar_Programa,COLOR_PAIR(4));
		wgetstr(Adicionar_Programa, Emissora);
		wattroff(Adicionar_Programa,COLOR_PAIR(4));


		if(strlen(Emissora)==1 && Emissora[0]=='0'){
				delwin(Adicionar_Programa);
				A_Programa();
		}else if(Checar_Emissora(Emissora)==0){
			wattron(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,22,64,"INSIRA UMA EMISSORA EXISTENTE");
			wattroff(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,24,70,"                                                                 ");
		}else{
			Aux++;
		}

	}while(Aux==0);


}


void A_Nome(char Nome[]){
	mvwprintw(Adicionar_Programa,24,0,"                                                                                                                                                                    ");
	mvwprintw(Adicionar_Programa,23,0,"                                                                                                                                                                   ");
	mvwprintw(Adicionar_Programa,22,0,"                                                                                                                                                                ");
	mvwprintw(Adicionar_Programa,21,0,"                                                                                                                   ");	

	int Aux=0;
	do{
		mvwprintw(Adicionar_Programa,24,70,"                                                                 ");

		mvwprintw(Adicionar_Programa,21,71,"NOME");
		wattron(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,23,40,"Insira o nome do programa ou insira 0 para cancelar e tecle ENTER");
		
		wattroff(Adicionar_Programa,COLOR_PAIR(2));
		mvwprintw(Adicionar_Programa,24,70,"");
		wattron(Adicionar_Programa,COLOR_PAIR(4));
		wgetstr(Adicionar_Programa, Nome);
		wattroff(Adicionar_Programa,COLOR_PAIR(4));

		if(strlen(Nome)==1 && Nome[0]=='0'){
			delwin(Adicionar_Programa);
			O_Programa();
		}else if(strlen(Nome)>25){	
			wattron(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,22,58,"O NOME DEVE CONTER MENOS DE 26 LETRAS");
			wattroff(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,28,70,"                                                                 ");
			Aux=0;

		}else if(Checar_Nome(Nome)==1){
			wattron(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,22,64,"ESTE NOME JA FOI INSERIDO");
			wattroff(Adicionar_Programa,COLOR_PAIR(3));
			mvwprintw(Adicionar_Programa,24,70,"                                                                 ");
			Aux=0;
		}else{
			Aux=1;
		}

	}while(Aux==0);


}