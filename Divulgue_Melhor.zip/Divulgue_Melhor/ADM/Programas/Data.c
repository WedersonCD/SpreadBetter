char *format(int number){      
   char    *retorno,
      ret[100];
   int    i;

   if (number < 10){
      sprintf(ret,"0%d",number);
      retorno = ret;
      return retorno;
   }
   else{
      sprintf(ret,"%d",number);
      retorno = ret;
      return retorno;
   }
}      

char *data(void){

   int dia,mes,ano;
   char   var1[100],
      var2[100],
      var3[100],
      var4[100],
      *dataPtr;
   struct tm *local;
   time_t t;

   t = time(NULL);
   local = localtime(&t);

   dia = local -> tm_mday;
   mes = local -> tm_mon + 1;
   ano = local -> tm_year + 1900;

   // por algum motivo precisa converter os valores retornados pelos ponteiros
   // da funcao em variaveis do tipo char      
   sprintf(var1,"%s",format(dia));
   sprintf(var2,"%s",format(mes));
   sprintf(var3,"%s",format(ano));

   // cria a variavel de retorno dos dados e cria um ponteiro para essa variavel      
   sprintf(var4,"%s-%s-%s",var3,var2,var1);

   // retorna data no formato dd:MM:yyyy com um ponteiro
   dataPtr = var4;
   return dataPtr;
}
