void Certifica_Visualizar(char Nome[]);
void Retorna_Dados_Programa(char ID[], char Nome[], char Emissora[], char H_Inicial[], char H_Final[], char Ibope[], char Tema[], char String_Regioes[]);

WINDOW *Visualizar_Programa;

void Limpar_V(){
	for(int x=0;x<60;x++)
		for(int y=0;y<153;y++)
		mvwprintw(Visualizar_Programa,x,y," ");
}

void V_Programa(){
int Aux=0;
do{
	Visualizar_Programa=newwin(150,150,0,0);
	keypad(Visualizar_Programa, TRUE);

	init_pair(1,COLOR_BLUE,COLOR_WHITE);
	init_pair(2,COLOR_GREEN,COLOR_WHITE);
	init_pair(3,COLOR_RED,COLOR_WHITE);
	init_pair(4,COLOR_BLACK,COLOR_WHITE);

	wbkgd(Visualizar_Programa,COLOR_PAIR(1));
	
	char ID[2]="";
	char Nome[26]="";
	char Emissora[26]="";
	char H_Inicial[8]="";
	char H_Final[8]="";
	char Ibope[3]="";
	char Tema[20]="";
	char String_Regioes[100]="";
	Certifica_Visualizar(Nome);
	Limpar_V();
	char Alternativa;


	do{
		Limpar_V();
		Retorna_Dados_Programa(ID, Nome, Emissora, H_Inicial, H_Final, Ibope, Tema, String_Regioes);
		wattron(Visualizar_Programa,COLOR_PAIR(2));
		mvwprintw(Visualizar_Programa,11,115,"Legenda:");
		mvwprintw(Visualizar_Programa,12,130,"S-Sul");
		mvwprintw(Visualizar_Programa,12,115,"N-Norte");
		mvwprintw(Visualizar_Programa,13,130,"SD-Suldeste");
		mvwprintw(Visualizar_Programa,13,115,"ND-Nordeste");
		mvwprintw(Visualizar_Programa,14,115,"CO-Centro_Oeste");
		wattroff(Visualizar_Programa,COLOR_PAIR(2));

		mvwprintw(Visualizar_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Visualizar_Programa,12,60,"ALTERAR PROGRAMA DE TV");
		mvwprintw(Visualizar_Programa,15,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Visualizar_Programa,16,5,"|Nome do programa           |Emissora                   |H_Inicial |H_Final |Ibope  |Tema Do Programa      |Regioes alcançadas       |");
		mvwprintw(Visualizar_Programa,17,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		mvwprintw(Visualizar_Programa,18,5,"|                           |                           |          |        |       |                      |                          |");
		mvwprintw(Visualizar_Programa,19,5,"+---------------------------+---------------------------+----------+--------+-------+----------------------+--------------------------+");
		
		wattron(Visualizar_Programa,COLOR_PAIR(4));
		mvwprintw(Visualizar_Programa,18,6,"%s",Nome);
		mvwprintw(Visualizar_Programa,18,34,"%s",Emissora);
		mvwprintw(Visualizar_Programa,18,62,"%s",H_Inicial);
		mvwprintw(Visualizar_Programa,18,73,"%s",H_Final);
		mvwprintw(Visualizar_Programa,18,82,"%s",Ibope);
		mvwprintw(Visualizar_Programa,18,90,"%s",Tema);
		mvwprintw(Visualizar_Programa,18,113,"%s",String_Regioes);
		wattroff(Visualizar_Programa,COLOR_PAIR(4));

		wattron(Visualizar_Programa,COLOR_PAIR(2));
		mvwprintw(Visualizar_Programa,22,47,"Pressione 1 para visualizar outro programa ou 0 para retornar ao menu.");
		wattroff(Visualizar_Programa,COLOR_PAIR(2));

		mvwprintw(Visualizar_Programa,23,0,"");
		Alternativa=wgetch(Visualizar_Programa);



		 if(Alternativa=='0'){
			O_Programa();
		}else{
			wattron(Visualizar_Programa,COLOR_PAIR(3));
			mvwprintw(Visualizar_Programa,21,55,"POR FAVOR PRESSIONE UM NUMERO VALIDO");
			wattroff(Visualizar_Programa,COLOR_PAIR(3));

		}
	}while(Alternativa!='1');
}while(Aux==0);
	wrefresh(Visualizar_Programa);
	delwin(Visualizar_Programa);

}


void Certifica_Visualizar(char Nome[]){


	for(int x=11;x<28;x++)mvwprintw(Visualizar_Programa,x,0,"                                                                                                                                                      ");

	int Aux=0;
	while(Aux==0){
		Limpar_V();
  	    Criar_Tabela(Visualizar_Programa,17, "Programa_De_TV");
		mvwprintw(Visualizar_Programa,10,0,"______________________________________________________________________________________________________________________________________________________");
		mvwprintw(Visualizar_Programa,12,60,"Visualizar programa");
		wattron(Visualizar_Programa,COLOR_PAIR(2));
		mvwprintw(Visualizar_Programa,14,35,"Digite o nome do programa que desejas visualizar ou digite 0 e aperte enter");
		wattroff(Visualizar_Programa,COLOR_PAIR(2));

		mvwprintw(Visualizar_Programa,15,70,"");
		wattron(Visualizar_Programa,COLOR_PAIR(4));
		wgetstr(Visualizar_Programa, Nome);
		wattroff(Visualizar_Programa,COLOR_PAIR(4));

		if(Nome[0]=='0'){
			O_Programa();
		}else if(Checar_Nome(Nome)==0){
			wattron(Visualizar_Programa,COLOR_PAIR(3));
			mvwprintw(Visualizar_Programa,13,60, "PROGRAMA NAO ENCONTRADO");
			wattroff(Visualizar_Programa,COLOR_PAIR(3));
		}else{
			Aux++;
		}
		mvwprintw(Visualizar_Programa,15,70,"                                          ");

	}
	mvwprintw(Visualizar_Programa,14,35,"                                                                                         ");
	mvwprintw(Visualizar_Programa,13,10,"                                                                                                                                                                   ");

}